"""HAL client adapters."""
