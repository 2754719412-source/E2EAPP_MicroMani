"""Real hardware driver adapters."""
