﻿# 阅读导航 04｜后端业务与采集
# 职责：管理录制会话和 episode；按时间戳组帧、排队写入 LeRobot，并提供数据集管理接口。
# 先看：DatasetRecorderService → FrameAssembler → TimedRingBuffer → LeRobotWriterThread。
# 全局阅读顺序与关联文件：docs/CODE_READING_GUIDE.md；逐文件目录：docs/SOURCE_INDEX.md。

from __future__ import annotations

import asyncio
import contextlib
import importlib
import inspect
import json
import math
import os
import queue
import re
import shutil
import subprocess
import sys
import time
import uuid
from bisect import bisect_left
from collections import deque
from collections.abc import Awaitable, Callable
from concurrent.futures import Future
from copy import deepcopy
from dataclasses import dataclass, replace
from pathlib import Path
from threading import Event, Lock, Thread
from types import SimpleNamespace
from typing import Any

from backend.core.config import SettingsService
from backend.core.defaults import ICF_KINEMATICS_DEFAULTS, ICF_TELEOP_DEFAULTS
from backend.core.force_config import hal_force_config_payload
from backend.core.logging import LogService, now_ms, stable_config_hash
from backend.core.motion_safety import MotionSafetyGate, motion_operation
from backend.core.units import lerobot_to_ui_state, motion_pulse_per_unit, pulses_to_ui_state
from backend.hal_client.client import HalClient
from backend.services.hardware_service import HardwareService
from backend.services.telemetry_hub import TelemetryHub
from backend.services.teleop_mapping import TeleopMappingService

SAFE_ID = re.compile(r"[^A-Za-z0-9_.-]+")
CAMERA_KEYS: tuple[str, str, str] = ("global", "wrist_left", "wrist_right")
# 这些 feature 名称需要和 LeRobot 数据集字段保持稳定，前后端按它们读取图像。
CAMERA_FEATURE_KEYS: dict[str, str] = {
    "global": "observation.images.global",
    "wrist_left": "observation.images.wrist_left",
    "wrist_right": "observation.images.wrist_right",
}
CAMERA_CAPTURE_SIZES: dict[str, tuple[int, int]] = {
    "global": (640, 480),
    "wrist_left": (640, 480),
    "wrist_right": (640, 480),
}
STATE_FEATURE_NAMES: tuple[str, ...] = (
    "left_x_um",
    "left_y_um",
    "left_z_um",
    "left_roll_mdeg",
    "left_pitch_mdeg",
    "left_yaw_mdeg",
    "left_gripper_gap_mm",
    "right_x_um",
    "right_y_um",
    "right_z_um",
    "right_roll_mdeg",
    "right_pitch_mdeg",
    "right_yaw_mdeg",
    "right_gripper_gap_mm",
)
PULSE_FEATURE_NAMES: tuple[str, ...] = (
    "left_x_pulse",
    "left_y_pulse",
    "left_z_pulse",
    "left_roll_pulse",
    "left_pitch_pulse",
    "left_yaw_pulse",
    "right_x_pulse",
    "right_y_pulse",
    "right_z_pulse",
    "right_roll_pulse",
    "right_pitch_pulse",
    "right_yaw_pulse",
)
MOTION_AXIS_NAMES: tuple[str, ...] = ("x", "y", "z", "roll", "pitch", "yaw")
LEROBOT_STATE_UNIT_SPEC: tuple[str, ...] = ("um", "um", "um", "mdeg", "mdeg", "mdeg")
FORCE_FEATURE_NAMES: tuple[str, ...] = ("fx", "fy", "fz", "mx", "my", "mz")
CAMERA_SOURCE_KEYS: dict[str, str] = {key: f"camera_{key}" for key in CAMERA_KEYS}
CAMERA_KEY_BY_SOURCE: dict[str, str] = {source: key for key, source in CAMERA_SOURCE_KEYS.items()}
SOURCE_KEYS: tuple[str, ...] = (
    "hal",
    "force",
    "gripper",
    *CAMERA_SOURCE_KEYS.values(),
    "omega",
)
SOURCE_TIMEOUT_S: dict[str, float] = {
    "hal": 0.050,
    "force": 0.020,
    "omega": 0.020,
    **{source: 0.035 for source in CAMERA_SOURCE_KEYS.values()},
}
# timeout 用 drop 边界，warning 用更严格的 skew 边界；这样慢但成功的源也会进入质量报告。
SOURCE_MAX_SKEW_S: dict[str, float] = {
    "hal": 0.020,
    "force": 0.010,
    "gripper": 0.050,
    "omega": 0.020,
    **{source: 0.035 for source in CAMERA_SOURCE_KEYS.values()},
}
SOURCE_WARNING_SKEW_MS: dict[str, float] = {
    source: max_skew_s * 1000.0 for source, max_skew_s in SOURCE_MAX_SKEW_S.items()
}
SOURCE_DROP_SKEW_MS: dict[str, float] = {source: 35.0 for source in CAMERA_SOURCE_KEYS.values()}
RING_BUFFER_RETENTION_S = 3.0
WRITE_QUEUE_MAX_FRAMES = 1200
WRITE_QUEUE_PUT_TIMEOUT_S = 1.0
ASSEMBLY_QUEUE_MAX_FRAMES = 120
ASSEMBLY_QUEUE_PUT_TIMEOUT_S = 1.0
NATIVE_WRITER_COMMAND_TIMEOUT_S = 5.0
NATIVE_SAVE_EPISODE_TIMEOUT_S = 60.0
RECORDING_QUEUE_DRAIN_TIMEOUT_S = 30.0
SAMPLER_START_LEAD_S = 0.05
RECORDER_HARDWARE_WARMUP_S = 0.5
MAX_SAMPLE_JITTER_S = 0.10
SAMPLE_LOOKBACK_WINDOW_S = 0.10
ALIGNMENT_DELAY_S = 0.100
SETTLE_TIMEOUT_MS = 20.0
ACTION_STALE_S = 1.0
HAL_NATIVE_SAMPLE_HZ = 1000.0
OMEGA_NATIVE_SAMPLE_HZ = 100.0
CRITICAL_ALIGNMENT_SOURCE_KEYS: tuple[str, ...] = ("hal", "force", "gripper", "omega")
# LeRobot starts a new parquet/mp4 file when current + next episode reaches this limit.
NATIVE_DATA_FILE_SIZE_MB = 0.000001
NATIVE_VIDEO_FILE_SIZE_MB = 0.000001


class DatasetSaveError(RuntimeError):
    """Raised when an episode cannot be persisted in the declared dataset format."""


@dataclass(frozen=True)
class TimedSample:
    # 记录每个硬件源相对录制 tick 的时序，用于质量统计而不写入训练帧。
    source: str
    monotonic_s: float
    value: Any
    ok: bool = True
    message: str = ""
    target_monotonic_s: float = 0.0
    started_monotonic_s: float = 0.0
    finished_monotonic_s: float = 0.0
    elapsed_ms: float = 0.0
    timed_out: bool = False
    stale: bool = False
    cache_used: bool = False


SourceSample = TimedSample


@dataclass(frozen=True)
class PendingFrame:
    # 写盘队列只传不可变帧快照，避免 episode 切换后旧帧写入新文件。
    episode_index: int
    frame_index: int
    timestamp: float
    frame: dict[str, Any]


# 存放采样数据的缓存区，按 source 分类，支持按时间查找最近样本。
@dataclass(frozen=True)
class FrameAssemblyJob:
    episode_index: int
    episode_generation: int
    frame_index: int
    target_monotonic_s: float
    period_s: float


@dataclass(frozen=True)
class WriterCommand:
    kind: str
    future: Future[Any]


# 写入边界：帧与保存/清空命令共用队列，由同一个线程串行访问 LeRobotDataset。
class LeRobotWriterThread:
    """Serialize LeRobotDataset access on a dedicated thread."""

    def __init__(self, recorder: Any, work_queue: queue.Queue[PendingFrame | WriterCommand | None]) -> None:
        """初始化 LeRobot 写线程、共享队列和线程内数据集状态。"""
        self._recorder = recorder
        self._queue = work_queue
        self._thread = Thread(target=self._run, name="lerobot-writer", daemon=True)
        self._dataset: Any | None = None
        self._error = ""

    def start(self) -> None:
        """启动负责串行写入 LeRobotDataset 的后台线程。"""
        self._thread.start()

    def join(self, timeout: float | None = None) -> None:
        """等待写入线程结束，支持可选超时。"""
        self._thread.join(timeout=timeout)

    def is_alive(self) -> bool:
        """返回写线程是否仍在消费命令。"""
        return self._thread.is_alive()

    def submit(self, kind: str) -> Future[Any]:
        """向写线程投递控制命令，并返回用于等待结果的 Future。"""
        future: Future[Any] = Future()
        try:
            self._queue.put_nowait(WriterCommand(kind, future))
        except queue.Full as exc:
            raise RuntimeError("native LeRobot writer command queue is full") from exc
        return future

    def _run(self) -> None:
        """循环消费写入队列，分发控制命令或落盘帧数据。"""
        while True:
            item = self._queue.get()
            try:
                if item is None:
                    return
                if isinstance(item, WriterCommand):
                    self._handle_command(item)
                    continue
                self._write_frame(item.frame)
            except Exception as exc:  # noqa: BLE001
                self._error = str(exc)
                self._recorder.logs.error("[LEROBOT]", f"writer recovered: {exc}")
            finally:
                self._queue.task_done()

    def _handle_command(self, command: WriterCommand) -> None:
        """执行打开、保存、清空和 finalize 等写线程控制命令。"""
        try:
            if command.kind == "open":
                self._dataset = self._recorder._open_native_dataset_for_writer()
                self._error = ""
                command.future.set_result(self._native_total_frames())
            elif command.kind == "save_episode":
                if self._error:
                    raise RuntimeError(self._error)
                if self._dataset is not None:
                    self._dataset.save_episode(parallel_encoding=True)
                command.future.set_result(self._native_total_frames())
            elif command.kind == "clear_episode":
                if self._dataset is not None:
                    self._dataset.clear_episode_buffer()
                self._error = ""
                command.future.set_result(None)
            elif command.kind == "finalize":
                dataset = self._dataset
                self._dataset = None
                if dataset is not None:
                    dataset.finalize()
                command.future.set_result(None)
            else:
                raise RuntimeError(f"unknown writer command: {command.kind}")
        except Exception as exc:  # noqa: BLE001
            self._error = str(exc)
            command.future.set_exception(exc)

    def _write_frame(self, frame: dict[str, Any]) -> None:
        """将仍属于当前 episode 的帧转换为 native payload 并写入数据集。"""
        if int(frame.get("episode_index", self._recorder._episode_index)) != self._recorder._episode_index:
            return
        if self._dataset is None:
            raise RuntimeError("native LeRobot writer is not open")
        native_frame = self._recorder._native_frame_payload(frame)
        self._dataset.add_frame(native_frame)
        self._recorder._mark_frame_written(frame)

    def _native_total_frames(self) -> int:
        """读取 native 数据集累计帧数，异常或缺失时返回 0。"""
        if self._dataset is None:
            return 0
        meta = getattr(self._dataset, "meta", None)
        total = getattr(meta, "total_frames", None)
        if total is None:
            total = getattr(self._dataset, "num_frames", 0)
        if total is None:
            return 0
        try:
            return int(total)
        except (TypeError, ValueError):
            return 0


class RecordingQualityTracker:
    """Keep per-episode timing counters out of the hot loop body."""

    def __init__(self, recorder: Any) -> None:
        """绑定录制器实例，用于集中记录 episode 质量指标。"""
        self._recorder = recorder

    def record_tick_locked(
        self,
        target_tick: float,
        scheduled_tick: float,
        capture_tick: float,
        period_s: float,
    ) -> None:
        """在已持有录制锁时记录帧调度偏移和迟到帧统计。"""
        if capture_tick > scheduled_tick + period_s:
            self._recorder._episode_late_frames += 1
        self._recorder._tick_target_monotonic_s = target_tick
        self._recorder._tick_capture_monotonic_s = target_tick + (capture_tick - scheduled_tick)
        self._recorder._tick_skews_ms.append((capture_tick - scheduled_tick) * 1000.0)


# 组帧边界：按同一单调时钟目标选择各源缓存；这里不串行等待每台设备完成一次新采样。
class FrameAssembler:
    """Assemble one training frame from sampler snapshots."""

    def __init__(self, recorder: Any) -> None:
        """绑定录制器实例，为后续从采样缓存组装训练帧做准备。"""
        self._recorder = recorder

    def assemble(self, config: dict[str, Any], target_monotonic_s: float, frame_index: int) -> dict[str, Any]:
        """从各源对齐样本组装一帧 LeRobot 训练数据。"""
        recorder = self._recorder
        motion_positions = list(recorder.telemetry.motion_positions)
        motion_pulses = recorder._latest_motion_pulses()
        force_left = list(recorder.telemetry.force_left)
        force_right = list(recorder.telemetry.force_right)
        hal_sample = recorder._aligned_sample("hal", target_monotonic_s)
        force_sample = recorder._aligned_sample("force", target_monotonic_s)
        gripper_sample = recorder._aligned_sample("gripper", target_monotonic_s)
        recorder._aligned_sample("omega", target_monotonic_s)
        motion_state = hal_sample.value if hal_sample.ok and isinstance(hal_sample.value, dict) else {}
        raw_positions = motion_state.get("positions") if isinstance(motion_state, dict) else None
        if isinstance(raw_positions, list) and len(raw_positions) == 12:
            motion_positions = [float(value) for value in raw_positions]
        raw_pulses = motion_state.get("pulses") if isinstance(motion_state, dict) else None
        if isinstance(raw_pulses, list) and len(raw_pulses) == 12:
            motion_pulses = [float(value) for value in raw_pulses]
            recorder._remember_motion_pulses(motion_pulses)
        motion_positions = recorder._recording_motion_positions(config, motion_positions, motion_pulses)
        force_values = recorder._force_values_from_sample(force_sample.value)
        if force_values is not None:
            force_left, force_right = force_values
        gripper_positions = (
            list(gripper_sample.value)
            if isinstance(gripper_sample.value, list)
            else list(recorder.telemetry.gripper_positions)
        )
        observation_state = recorder._compose_observation_state(motion_positions, gripper_positions)
        image_payload: dict[str, Any] = {}
        for camera, source in CAMERA_SOURCE_KEYS.items():
            feature_key = CAMERA_FEATURE_KEYS[camera]
            camera_sample = recorder._aligned_sample(source, target_monotonic_s)
            image_payload[feature_key] = (
                camera_sample.value
                if camera_sample.value is not None
                else recorder._camera_placeholder_value(feature_key)
            )
        return {
            "timestamp": frame_index / max(1, recorder._record_fps_hz),
            "frame_index": frame_index,
            "episode_index": recorder._episode_index,
            "observation.state": observation_state,
            "observation.pulses": motion_pulses,
            "observation.force_left": force_left,
            "observation.force_right": force_right,
            "action": recorder._latest_action_vector(observation_state, config, target_monotonic_s),
            "images": image_payload,
        }


# 对齐基础：缓存按采样时间排序，nearest 只接受最大偏差内的样本；缺样由上层决定回退方式。
class TimedRingBuffer:
    def __init__(self, *, retention_s: float = RING_BUFFER_RETENTION_S, maxlen: int = 300) -> None:
        """初始化带保留时长和最大长度限制的线程安全时间环形缓存。"""
        self.retention_s = max(float(retention_s), 0.1)
        self.maxlen = max(int(maxlen), 1)
        self._samples: deque[TimedSample] = deque()
        self._lock = Lock()

    def append(self, sample: TimedSample) -> None:
        """按采样时间插入样本，并裁剪过期或超长缓存。"""
        with self._lock:
            if not self._samples or sample.monotonic_s >= self._samples[-1].monotonic_s:
                self._samples.append(sample)
            else:
                samples = list(self._samples)
                index = bisect_left([item.monotonic_s for item in samples], sample.monotonic_s)
                samples.insert(index, sample)
                self._samples = deque(samples)
            latest_s = max(item.monotonic_s for item in self._samples)
            self._prune_locked(latest_s - self.retention_s)
            while len(self._samples) > self.maxlen:
                self._samples.popleft()

    def nearest(self, target_s: float, max_skew_s: float) -> TimedSample | None:
        """查找距离目标时间最近且不超过允许偏差的样本。"""
        with self._lock:
            if not self._samples:
                return None
            samples = list(self._samples)
        times = [sample.monotonic_s for sample in samples]
        index = bisect_left(times, target_s)
        candidates = []
        if index < len(samples):
            candidates.append(samples[index])
        if index > 0:
            candidates.append(samples[index - 1])
        if not candidates:
            return None
        nearest = min(candidates, key=lambda sample: abs(sample.monotonic_s - target_s))
        return nearest if abs(nearest.monotonic_s - target_s) <= max_skew_s else None

    def has_at_or_after(self, target_s: float) -> bool:
        """判断缓存是否已有达到或晚于目标时间的样本。"""
        with self._lock:
            return bool(self._samples and self._samples[-1].monotonic_s >= target_s)

    def _prune_locked(self, before_s: float) -> None:
        """在持锁状态下移除早于指定时间的旧样本。"""
        while self._samples and self._samples[0].monotonic_s < before_s:
            self._samples.popleft()

    def clear(self) -> None:
        """清空所有已缓存的时间样本。"""
        with self._lock:
            self._samples.clear()

    def __len__(self) -> int:
        """返回当前缓存中的样本数量。"""
        with self._lock:
            return len(self._samples)


class DatasetRecorderService:
    def __init__(
        self,
        settings: SettingsService,
        hardware: HardwareService,
        hal: HalClient,
        telemetry: TelemetryHub,
        logs: LogService,
        teleop: TeleopMappingService,
        safety: MotionSafetyGate | None = None,
    ) -> None:
        """初始化录制服务依赖、会话状态、队列、采样缓存和质量统计字段。"""
        self.settings = settings
        self.hardware = hardware
        self.hal = hal
        self.telemetry = telemetry
        self.logs = logs
        self.teleop = teleop
        self.safety = safety if safety is not None else MotionSafetyGate()
        self._lock = asyncio.Lock()
        self._loop_task: asyncio.Task[None] | None = None
        self._assembler_task: asyncio.Task[None] | None = None
        self._writer_thread: LeRobotWriterThread | None = None
        self._sampler_threads: dict[str, Thread] = {}
        self._sampler_stop_event = Event()
        self._assembly_queue: asyncio.Queue[FrameAssemblyJob] | None = None
        self._write_queue: queue.Queue[PendingFrame | WriterCommand | None] = queue.Queue(
            maxsize=WRITE_QUEUE_MAX_FRAMES
        )
        self._write_enqueue_pending = 0
        self._write_enqueue_idle = asyncio.Event()
        self._write_enqueue_idle.set()
        self._session_active = False
        self._session_starting = False
        self._recording = False
        self._accepting_frame_jobs = False
        self._samplers_paused = False
        self._session_id = ""
        self._dataset_id = ""
        self._dataset_name = ""
        self._task = ""
        self._dataset_dir: Path | None = None
        self._episode_index = 0
        self._episode_generation = 0
        self._episode_started_at = 0.0
        self._episode_start_monotonic_s = 0.0
        self._sampler_start_monotonic_s = 0.0
        self._sampler_schedule_start_s = 0.0
        self._record_loop_start_monotonic_s = 0.0
        self._episode_source_time0_s = 0.0
        self._session_started_at = 0.0
        self._episode_frames = 0
        self._queued_episode_frames = 0
        self._episode_late_frames = 0
        self._camera_drops = {key: 0 for key in CAMERA_KEYS}
        self._camera_min_fps: dict[str, float] = {}
        self._camera_worker_fallbacks: set[str] = set()
        self._tick_target_monotonic_s = 0.0
        self._tick_capture_monotonic_s = 0.0
        self._tick_skews_ms: list[float] = []
        self._last_telemetry_frame_update_s = 0.0
        self._drop_counts: dict[str, int] = {key: 0 for key in (*CAMERA_KEYS, *SOURCE_KEYS)}
        self._stale_counts: dict[str, int] = {key: 0 for key in SOURCE_KEYS}
        self._cache_counts: dict[str, int] = {key: 0 for key in SOURCE_KEYS}
        self._late_source_frames: dict[str, int] = {}
        self._source_skews_ms: dict[str, list[float]] = {key: [] for key in SOURCE_KEYS}
        self._source_elapsed_ms: dict[str, list[float]] = {key: [] for key in SOURCE_KEYS}
        self._source_fail_streaks: dict[str, int] = {key: 0 for key in SOURCE_KEYS}
        self._source_warnings: list[str] = []
        self._max_force_left = 0.0
        self._max_force_right = 0.0
        self._native_dataset: Any | None = None
        self._native_error = ""
        self._native_use_videos = False
        self._native_dataset_from_index = 0
        self._native_total_frames_cached = 0
        self._last_native_camera_frames: dict[str, Any] = {}
        self._last_native_gripper_sample: tuple[tuple[float, float], float] | None = None
        self._record_fps_hz = 30
        self._force_sample_hz = 200.0
        self._latest_force_state: dict[str, Any] = {}
        self._recording_config_snapshot: dict[str, Any] = {}
        self._last_motion_pulses = [0.0] * 12
        self._source_sample_indices: dict[str, int] = {key: 0 for key in SOURCE_KEYS}
        self._sample_buffers: dict[str, TimedRingBuffer] = self._new_sample_buffers({})
        self._frame_assembler = FrameAssembler(self)
        self._quality_tracker = RecordingQualityTracker(self)
        self._last_saved_episode: dict[str, Any] | None = None
        self._reset_pending = False
        self._reset_required_sides: set[str] = {"left"}
        self._reset_returned_sides: set[str] = set()
        self._hub_push_jobs: dict[str, dict[str, Any]] = {}
        self._hub_push_jobs_lock = Lock()

    # 会话入口：从这里沿准备数据集、启动采样/遥操作及异常清理阅读，再看 save_episode 和 finish_session。
    @motion_operation()
    async def start_session(self, dataset_name: str, task: str) -> dict[str, Any]:
        """创建录制会话，初始化 native 写入路径、采样线程和组帧任务。"""
        safety_token = self.safety.capture()
        self.safety.check(safety_token)
        validator = getattr(self, "validate_start_origin", None)
        if validator is not None:
            await validator()
        async with self._lock:
            if self._session_active or self._session_starting:
                raise RuntimeError("record session already active")
            self._session_starting = True
            self._safety_interrupted = False

        try:
            config = await asyncio.to_thread(self.settings.get_config)
            next_dataset_name = dataset_name.strip() or "micro_assembly_v1"
            next_dataset_id = self._safe_id(next_dataset_name)
            next_task = task.strip() or "unspecified task"
            dataset_root = self._dataset_root(config)
            dataset_dir = dataset_root / next_dataset_id
            await asyncio.to_thread(dataset_root.mkdir, parents=True, exist_ok=True)

            async with self._lock:
                self._recording_config_snapshot = deepcopy(config)
                self._dataset_name = next_dataset_name
                self._dataset_id = next_dataset_id
                self._task = next_task
                self._session_id = f"session-{now_ms()}"
                self._last_saved_episode = None
                self._reset_pending = False
                self._reset_required_sides = {"left"}
                self._reset_returned_sides = set()
                self._record_fps_hz = self._record_fps_from_config(config)
                self._force_sample_hz = self._force_sample_hz_from_config(config)
                self._dataset_dir = dataset_dir
                self._native_dataset = None
                self._native_error = ""
                self._native_total_frames_cached = 0
                self._last_native_camera_frames = {}
                self._last_native_gripper_sample = None
                self._assembly_queue = asyncio.Queue(maxsize=ASSEMBLY_QUEUE_MAX_FRAMES)
                self._write_queue = queue.Queue(maxsize=WRITE_QUEUE_MAX_FRAMES)
                self._writer_thread = LeRobotWriterThread(self, self._write_queue)
                self._writer_thread.start()
        except (asyncio.CancelledError, Exception):
            async with self._lock:
                self._session_starting = False
            raise

        try:
            if (
                self._real_hardware_mode(config)
                and str(config.get("force", {}).get("source", "hkvl_serial")).lower() == "hkvl_serial"
            ):
                try:
                    self._latest_force_state = dict(await self.hal.force_state())
                except Exception as exc:  # noqa: BLE001
                    self._latest_force_state = {}
                    self.logs.warning("[FORCE]", f"HKVL metadata state unavailable: {exc}")
            native_started = await self._try_begin_native_dataset(config)
            if not native_started:
                await self._stop_writer_task()
                raise RuntimeError(self._native_required_message())
        except (asyncio.CancelledError, Exception):
            async with self._lock:
                self._session_starting = False
            raise

        try:
            await asyncio.to_thread(self._write_appstation_info, dataset_dir, config)
            episode_index = await asyncio.to_thread(self._next_episode_index, dataset_dir)
            sample_clock_now_s, schedule_now_s = await self._episode_clock_pair(config)
            async with self._lock:
                self.safety.check(safety_token)
                self._dataset_dir = dataset_dir
                self._episode_index = episode_index
                self._session_started_at = time.monotonic()
                self._session_active = True
                self._session_starting = False
                self._write_enqueue_pending = 0
                self._write_enqueue_idle.set()
                self._begin_episode_locked(sample_clock_now_s=sample_clock_now_s, schedule_now_s=schedule_now_s)
                self._start_sampler_tasks_locked()
                self._loop_task = asyncio.create_task(self._record_loop(), name="dataset-recorder")
                self._assembler_task = asyncio.create_task(self._frame_assembler_loop(), name="dataset-frame-assembler")
                self.telemetry.episode_count = self._episode_index
                self.telemetry.frame_count = 0
                self.telemetry.recording = True
            if self._real_hardware_mode(config):
                await self._refresh_gripper_cache(config)
            self.safety.check(safety_token)
            await self.teleop.start("recording", pre_home=False)
            await self._wait_for_episode_warmup()
            self.safety.check(safety_token)
        except (asyncio.CancelledError, Exception):
            async with self._lock:
                self._session_starting = False
            await self._rollback_failed_start()
            raise
        self.logs.info("[LEROBOT]", f"record session started: {self._dataset_name} episode={self._episode_index:06d}")
        return await asyncio.to_thread(self.status)

    @property
    def safety_interrupted(self) -> bool:
        return self._session_active and getattr(self, "_safety_interrupted", False)

    def interrupt_for_safety(self) -> None:
        """同步封住新采样，保留未保存 episode，异步停止遥操作并排空既有队列。"""
        if not self._session_active or getattr(self, "_safety_interrupted", False):
            return
        self._safety_interrupted = True
        self._accepting_frame_jobs = False
        self._samplers_paused = True
        self.telemetry.recording = False
        self.logs.warning("[LEROBOT]", "safety interrupted recording; unsaved episode retained for review")

        async def settle() -> None:
            try:
                await asyncio.wait_for(self.teleop.stop("recording"), 1.0)
            except Exception as exc:
                self.logs.error("[LEROBOT]", f"interrupted teleop stop unconfirmed: {exc}")
            try:
                await asyncio.wait_for(self._drain_recording_queues(), 5.0)
                self._recording = False
            except Exception as exc:
                self.logs.error("[LEROBOT]", f"interrupted recording drain failed; data retained: {exc}")

        self._interruption_task = asyncio.create_task(settle(), name="record-safety-interruption")

    async def save_episode(self) -> dict[str, Any]:
        """停止当前 episode 采集，等待队列落盘并保存 episode 元数据。"""
        pending = getattr(self, "_interruption_task", None)
        if pending is not None:
            await asyncio.shield(pending)
        async with self._lock:
            if not self._session_active:
                raise RuntimeError("record session is not active")
            self._accepting_frame_jobs = False
            self.telemetry.recording = False
        try:
            await self.teleop.stop("recording")
            await self._drain_recording_queues()
            if self._native_writer_active():
                await self._save_native_episode()
            async with self._lock:
                self._recording = False
                self._accepting_frame_jobs = False
                episode = await asyncio.to_thread(self._finalize_episode_locked, status="review", deleted=False)
                self._last_saved_episode = episode
                self._enter_reset_pending_locked()
                self._samplers_paused = True
                self.telemetry.episode_count = self._episode_index + 1
        except Exception:
            async with self._lock:
                self._recording = False
                self._accepting_frame_jobs = False
                self._enter_reset_pending_locked()
                self._samplers_paused = True
                self.telemetry.recording = False
            if self._native_writer_active():
                with contextlib.suppress(Exception):
                    await self._clear_native_episode_buffer()
            with contextlib.suppress(Exception):
                await self.teleop.stop("recording")
            raise
        self.logs.info("[LEROBOT]", f"record episode saved: {episode['id']}")
        return {"episode": episode, "status": await asyncio.to_thread(self.status)}

    async def discard_episode(self) -> dict[str, Any]:
        """丢弃正在录制或刚保存的 episode，并暂停到复位等待。"""
        pending = getattr(self, "_interruption_task", None)
        if pending is not None:
            await asyncio.shield(pending)
        async with self._lock:
            if not self._session_active:
                raise RuntimeError("record session is not active")
            was_recording = self._recording
            if was_recording:
                self._recording = False
                self._accepting_frame_jobs = False
                self.telemetry.recording = False
        if was_recording:
            await self._drain_recording_queues()
            if self._native_writer_active():
                await self._clear_native_episode_buffer()
        async with self._lock:
            if not was_recording and self._last_saved_episode is not None:
                episode_index = int(self._last_saved_episode.get("episodeIndex", self._episode_index))
                await asyncio.to_thread(self._mark_saved_episode_deleted_locked, self._last_saved_episode)
                if episode_index < self._episode_index:
                    self._episode_index = episode_index
                    self.telemetry.episode_count = episode_index
                self._last_saved_episode = None
            self._enter_reset_pending_locked()
            self._samplers_paused = True
            self.telemetry.recording = False
        await self.teleop.stop("recording")
        self.logs.warning("[LEROBOT]", f"record episode discarded; waiting for reset episode={self._episode_index:06d}")
        return await asyncio.to_thread(self.status)

    @motion_operation()
    async def skip_reset(self) -> dict[str, Any]:
        """跳过复位等待，清理已保存标记并启动下一条 episode 录制。"""
        if getattr(self, "_safety_interrupted", False) and not self._reset_pending:
            raise RuntimeError("interrupted episode must be saved or discarded before restarting")
        validator = getattr(self, "validate_start_origin", None)
        if validator is not None:
            await validator()
        safety_token = self.safety.capture()
        self.safety.check(safety_token)
        sample_clock_now_s, schedule_now_s = await self._episode_clock_pair(self._recording_config())
        pending = getattr(self, "_interruption_task", None)
        if pending is not None:
            await asyncio.shield(pending)
        async with self._lock:
            self.safety.check(safety_token)
            if not self._session_active:
                raise RuntimeError("record session is not active")
            reset_pending = getattr(self, "_reset_pending", self._last_saved_episode is not None)
            if self._recording or not reset_pending:
                raise RuntimeError("record reset is not ready")
            if not self._reset_ready_locked():
                raise RuntimeError("record reset work origin is not ready")
            previous_last_saved_episode = self._last_saved_episode
            previous_reset_pending = bool(getattr(self, "_reset_pending", reset_pending))
            previous_reset_required_sides = self._reset_required_sides_locked()
            previous_reset_returned_sides = self._reset_returned_sides_locked()
            previous_samplers_paused = bool(getattr(self, "_samplers_paused", False))
            try:
                self._last_saved_episode = None
                self._reset_pending = False
                self._reset_returned_sides = set()
                self._begin_episode_locked(sample_clock_now_s=sample_clock_now_s, schedule_now_s=schedule_now_s)
                self.telemetry.recording = True
                self.telemetry.frame_count = 0
            except (asyncio.CancelledError, Exception):
                self._last_saved_episode = previous_last_saved_episode
                self._reset_pending = previous_reset_pending
                self._reset_required_sides = previous_reset_required_sides
                self._reset_returned_sides = previous_reset_returned_sides
                self._samplers_paused = previous_samplers_paused
                raise
        try:
            self.safety.check(safety_token)
            await self.teleop.start("recording", pre_home=False)
            await self._wait_for_episode_warmup()
            self.safety.check(safety_token)
        except (asyncio.CancelledError, Exception):
            async with self._lock:
                self._recording = False
                self._accepting_frame_jobs = False
                self._last_saved_episode = previous_last_saved_episode
                self._reset_pending = previous_reset_pending
                self._reset_required_sides = previous_reset_required_sides
                self._reset_returned_sides = previous_reset_returned_sides
                self._samplers_paused = previous_samplers_paused
                self.telemetry.recording = False
                self.telemetry.frame_count = 0
            with contextlib.suppress(Exception):
                await self.teleop.stop("recording")
            raise
        self.logs.info("[LEROBOT]", f"reset skipped; recording episode={self._episode_index:06d}")
        return await asyncio.to_thread(self.status)

    async def finish_session(self) -> dict[str, Any]:
        """结束当前录制会话，停止采样、组帧、写入和 teleop 任务。"""
        pending = getattr(self, "_interruption_task", None)
        if pending is not None:
            await asyncio.shield(pending)
        async with self._lock:
            was_recording = self._session_active and self._recording
            if was_recording:
                self._recording = False
                self._accepting_frame_jobs = False
                self.telemetry.recording = False
        if was_recording:
            await self._drain_recording_queues()
            if self._native_writer_active():
                await self._clear_native_episode_buffer()
        async with self._lock:
            self._recording = False
            self._accepting_frame_jobs = False
            self._session_active = False
            self._session_starting = False
            self._last_saved_episode = None
            self._reset_pending = False
            self._reset_returned_sides = set()
            self.telemetry.recording = False
            self.telemetry.frame_count = 0
        await self.teleop.stop("recording")
        task = self._loop_task
        if task is not None and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._loop_task = None
        cleanup_error: Exception | None = None

        async def run_cleanup(label: str, cleanup: Callable[[], Awaitable[None]]) -> None:
            nonlocal cleanup_error
            try:
                await cleanup()
            except Exception as exc:  # noqa: BLE001
                if cleanup_error is None:
                    cleanup_error = exc
                self.logs.error("[LEROBOT]", f"record session cleanup {label} failed: {exc}")

        await run_cleanup("frame assembler", self._stop_assembler_task)
        await run_cleanup("samplers", self._stop_sampler_tasks)
        await run_cleanup("native dataset", self._finalize_native_dataset)
        await run_cleanup("writer", self._stop_writer_task)
        if cleanup_error is not None:
            raise cleanup_error
        self.logs.info("[LEROBOT]", "record session finished")
        return await asyncio.to_thread(self.status)

    def _ordered_reset_sides(self, sides: set[str]) -> list[str]:
        return [side for side in ("left", "right") if side in sides]

    def _reset_required_sides_locked(self) -> set[str]:
        raw = getattr(self, "_reset_required_sides", {"left"})
        sides = {str(side) for side in raw if str(side) in {"left", "right"}}
        return sides or {"left"}

    def _reset_returned_sides_locked(self) -> set[str]:
        raw: Any = getattr(self, "_reset_returned_sides", set())
        return {str(side) for side in raw if str(side) in {"left", "right"}}

    def _reset_ready_locked(self) -> bool:
        if not bool(getattr(self, "_reset_pending", False)):
            return False
        required = self._reset_required_sides_locked()
        returned = self._reset_returned_sides_locked()
        return required.issubset(returned)

    def _enter_reset_pending_locked(self) -> None:
        self._reset_pending = True
        self._reset_required_sides = {"left"}
        self._reset_returned_sides = set()

    def mark_reset_origin_returned(self, side: str) -> None:
        if side not in {"left", "right"} or not bool(getattr(self, "_reset_pending", False)):
            return
        returned = self._reset_returned_sides_locked()
        returned.add(side)
        self._reset_returned_sides = returned

    def mark_reset_origin_all_returned(self) -> None:
        if not bool(getattr(self, "_reset_pending", False)):
            return
        self._reset_returned_sides = self._reset_required_sides_locked()

    def status(self) -> dict[str, Any]:
        """返回当前会话、episode、队列写入格式和 teleop 状态。"""
        elapsed = max(0.0, time.monotonic() - self._episode_started_at) if self._recording else 0.0
        reset_pending = bool(getattr(self, "_reset_pending", False))
        reset_required_sides = self._reset_required_sides_locked()
        reset_returned_sides = self._reset_returned_sides_locked()
        return {
            "session": self._session_id,
            "datasetId": self._dataset_id,
            "datasetName": self._dataset_name,
            "task": self._task,
            "active": self._session_active,
            "recording": self._recording and not getattr(self, "_safety_interrupted", False),
            "safetyInterrupted": getattr(self, "_safety_interrupted", False),
            "episodeIndex": self._episode_index,
            "frameCount": max(self._queued_episode_frames, self._episode_frames),
            "lateFrames": self._episode_late_frames,
            "elapsedS": round(elapsed, 3),
            "fps": self._record_fps_hz,
            "forceSampleHz": self._force_sample_hz,
            "datasetRoot": str(self._dataset_root(self.settings.get_config())),
            "format": "lerobot-v3-native" if self._native_writer_active() else "lerobot-v3-native-required",
            "nativeError": self._native_error,
            "teleop": self.teleop.status(),
            "resetPending": reset_pending,
            "resetRequiredSides": self._ordered_reset_sides(reset_required_sides),
            "resetReturnedSides": self._ordered_reset_sides(reset_returned_sides),
            "resetReady": reset_pending and reset_required_sides.issubset(reset_returned_sides),
        }

    def origin_mutation_locked(self) -> bool:
        """录制会话存在时禁止修改硬件零点记录，保持 episode 坐标系可追溯。"""
        return bool(getattr(self, "_session_starting", False) or self._session_active or self._recording)

    def list_datasets(self) -> list[dict[str, Any]]:
        """扫描数据集根目录，返回按更新时间排序的本地数据集摘要。"""
        root = self._dataset_root(self.settings.get_config())
        if not root.exists():
            return []
        datasets: list[dict[str, Any]] = []
        for dataset_dir in (item for item in root.iterdir() if item.is_dir()):
            info = self._read_json(dataset_dir / "meta" / "info.json")
            if not info:
                continue
            app_info = self._read_json(dataset_dir / "meta" / "appstation_info.json")
            native_format = self._is_native_dataset(dataset_dir, info)
            episodes = self._read_episodes(dataset_dir)
            if not episodes and native_format:
                episodes = self._native_episodes_from_meta(dataset_dir, info)
            visible_episodes = [
                episode
                for episode in episodes
                if not bool(episode.get("deleted", False)) and str(episode.get("status", "review")) != "invalid"
            ]
            datasets.append(
                {
                    "id": dataset_dir.name,
                    "name": str(app_info.get("name") or info.get("name") or dataset_dir.name),
                    "status": str(app_info.get("status") or info.get("status") or "local"),
                    "root": str(dataset_dir),
                    "fps": int(info.get("fps", 30)),
                    "createdAt": int(info.get("createdAt", 0)),
                    "updatedAt": int(app_info.get("updatedAt") or info.get("updatedAt", 0)),
                    "format": str(
                        app_info.get("format")
                        or info.get("format")
                        or ("lerobot-v3-native" if native_format else "lerobot-v3-native-required")
                    ),
                    "episodes": [
                        self._episode_for_api(dataset_dir, dataset_dir.name, episode, include_samples=False)
                        for episode in visible_episodes
                    ],
                }
            )
        return sorted(datasets, key=lambda item: int(item.get("updatedAt", 0)), reverse=True)

    def create_dataset(self, payload: dict[str, Any]) -> dict[str, Any]:
        """创建新的本地 native LeRobot 数据集目录及基础元数据。"""
        config = self.settings.get_config()
        name = str(payload.get("name") or f"dataset_{now_ms()}").strip()
        dataset_id = self._safe_id(name)
        dataset_dir = self._dataset_root(config) / dataset_id
        suffix = 1
        while dataset_dir.exists() and (dataset_dir / "meta" / "info.json").exists():
            dataset_id = self._safe_id(f"{name}_{suffix}")
            dataset_dir = self._dataset_root(config) / dataset_id
            suffix += 1
        previous_name = self._dataset_name
        try:
            self._dataset_name = name
            dataset_dir.mkdir(parents=True, exist_ok=True)
            if not self._create_native_dataset_metadata(dataset_dir, config):
                try:
                    if dataset_dir.exists() and not any(dataset_dir.iterdir()):
                        dataset_dir.rmdir()
                except OSError:
                    pass
                raise RuntimeError(self._native_required_message())
        finally:
            self._dataset_name = previous_name
        return {"dataset": self._episode_dataset_stub(dataset_dir)}

    def update_dataset(self, dataset_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        """更新数据集名称等展示信息，并兼容 native appstation 元数据。"""
        dataset_dir = self._dataset_path(dataset_id)
        info_path = dataset_dir / "meta" / "info.json"
        info = self._read_json(info_path)
        if not info:
            raise FileNotFoundError(dataset_id)
        name = str(payload.get("name", "")).strip()
        if self._is_native_dataset(dataset_dir, info):
            app_info_path = dataset_dir / "meta" / "appstation_info.json"
            app_info = self._read_json(app_info_path)
            if name:
                app_info["name"] = name
            app_info.setdefault("name", dataset_dir.name)
            app_info.setdefault("status", "local")
            app_info.setdefault("format", "lerobot-v3-native")
            app_info["updatedAt"] = now_ms()
            self._write_json(app_info_path, app_info)
            return {"dataset": self._episode_dataset_stub(dataset_dir)}
        if name:
            info["name"] = name
        info["updatedAt"] = now_ms()
        self._write_json(info_path, info)
        return {"dataset": self._episode_dataset_stub(dataset_dir)}

    def delete_dataset(self, dataset_id: str) -> dict[str, Any]:
        """校验目标位于数据集根目录后删除整个数据集目录。"""
        dataset_dir = self._dataset_path(dataset_id)
        root = self._dataset_root(self.settings.get_config()).resolve()
        target = dataset_dir.resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise RuntimeError("refusing to delete outside dataset root") from exc
        if not dataset_dir.exists():
            raise FileNotFoundError(dataset_id)
        shutil.rmtree(dataset_dir)
        return {"deleted": dataset_id}

    def save_review(self, dataset_id: str) -> dict[str, Any]:
        """刷新数据集审核保存时间，并写回对应元数据文件。"""
        dataset_dir = self._dataset_path(dataset_id)
        info_path = dataset_dir / "meta" / "info.json"
        info = self._read_json(info_path)
        if not info:
            raise FileNotFoundError(dataset_id)
        if self._is_native_dataset(dataset_dir, info):
            app_info_path = dataset_dir / "meta" / "appstation_info.json"
            app_info = self._read_json(app_info_path)
            app_info.setdefault("name", dataset_dir.name)
            app_info.setdefault("status", "local")
            app_info.setdefault("format", "lerobot-v3-native")
            app_info["updatedAt"] = now_ms()
            self._write_json(app_info_path, app_info)
            return {"saved": dataset_id, "updatedAt": app_info["updatedAt"]}
        info["updatedAt"] = now_ms()
        self._write_json(info_path, info)
        return {"saved": dataset_id, "updatedAt": info["updatedAt"]}

    def export_dataset(self, dataset_id: str) -> dict[str, Any]:
        """返回本地导出状态和格式信息，当前不执行真实 Hub 上传。"""
        dataset_dir = self._dataset_path(dataset_id)
        if not (dataset_dir / "meta" / "info.json").exists():
            raise FileNotFoundError(dataset_id)
        config = self.settings.get_config()
        push_enabled = bool(config.get("storage", {}).get("pushToHub", False))
        info = self._read_json(dataset_dir / "meta" / "info.json")
        fmt = "lerobot-v3-native" if self._is_native_dataset(dataset_dir, info) else "lerobot-v3-native-required"
        return {
            "dataset": dataset_id,
            "pushToHub": push_enabled,
            "exported": False,
            "format": fmt,
            "message": f"pushToHub is disabled; local {fmt} dataset is ready"
        }

    def update_hub_settings(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Update dataset Hub upload switches without handling any credentials."""
        config = self.settings.get_config()
        storage = dict(config.get("storage", {}))
        storage["pushToHub"] = bool(payload.get("pushToHub", False))
        config["storage"] = storage
        saved = self.settings.save_config(config)
        return {"pushToHub": bool(saved.get("storage", {}).get("pushToHub", False))}

    def dataset_stats(self, dataset_id: str) -> dict[str, Any]:
        """汇总数据集可见 episode 的帧数、时长、状态、力值和告警统计。"""
        dataset_dir = self._dataset_path(dataset_id)
        info = self._read_json(dataset_dir / "meta" / "info.json")
        if not info:
            raise FileNotFoundError(dataset_id)
        episodes = self._visible_episodes_for_dataset(dataset_dir, info)
        status_counts: dict[str, int] = {}
        warnings: list[str] = []
        total_frames = 0
        total_duration = 0.0
        max_force_left = 0.0
        max_force_right = 0.0
        for episode in episodes:
            status = str(episode.get("status") or "review")
            status_counts[status] = status_counts.get(status, 0) + 1
            total_frames += int(episode.get("frames", 0))
            total_duration += float(episode.get("durationS", 0.0))
            max_force_left = max(max_force_left, float(episode.get("maxForceLeft", 0.0)))
            max_force_right = max(max_force_right, float(episode.get("maxForceRight", 0.0)))
            raw_warnings = episode.get("warnings", [])
            if isinstance(raw_warnings, list):
                warnings.extend(str(item) for item in raw_warnings[:5])
        return {
            "dataset": dataset_id,
            "format": (
                "lerobot-v3-native"
                if self._is_native_dataset(dataset_dir, info)
                else str(info.get("format", "unknown"))
            ),
            "fps": int(info.get("fps", 30)),
            "episodes": len(episodes),
            "frames": total_frames,
            "durationS": round(total_duration, 3),
            "statusCounts": status_counts,
            "maxForceLeft": max_force_left,
            "maxForceRight": max_force_right,
            "warnings": warnings[:50],
            "features": info.get("features", {}),
        }

    def episode_detail(self, dataset_id: str, episode_id: str) -> dict[str, Any]:
        """按 episode_id 查找可见 episode 并转换为 API 响应结构。"""
        dataset_dir = self._dataset_path(dataset_id)
        info = self._read_json(dataset_dir / "meta" / "info.json")
        if not info:
            raise FileNotFoundError(dataset_id)
        episode = next(
            (
                item
                for item in self._visible_episodes_for_dataset(dataset_dir, info)
                if str(item.get("id")) == episode_id
            ),
            None,
        )
        if episode is None:
            raise FileNotFoundError(episode_id)
        return {"episode": self._episode_for_api(dataset_dir, dataset_id, episode)}

    def split_dataset(self, dataset_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        """按给定比例生成 train/val/test episode 划分并写入 splits.json。"""
        dataset_dir = self._dataset_path(dataset_id)
        info = self._read_json(dataset_dir / "meta" / "info.json")
        if not info:
            raise FileNotFoundError(dataset_id)
        episodes = self._visible_episodes_for_dataset(dataset_dir, info)
        episode_ids = sorted(str(episode.get("id", "")) for episode in episodes if episode.get("id"))
        ratios = payload.get("ratios", {})
        if not isinstance(ratios, dict):
            ratios = {}
        train_ratio = self._positive_ratio(ratios.get("train", 0.8), 0.8)
        val_ratio = self._positive_ratio(ratios.get("val", 0.1), 0.1)
        test_ratio = self._positive_ratio(ratios.get("test", 0.1), 0.1)
        total_ratio = max(train_ratio + val_ratio + test_ratio, 0.001)
        count = len(episode_ids)
        train_count = min(count, int(round(count * train_ratio / total_ratio)))
        val_count = min(count - train_count, int(round(count * val_ratio / total_ratio)))
        split = {
            "train": episode_ids[:train_count],
            "val": episode_ids[train_count : train_count + val_count],
            "test": episode_ids[train_count + val_count :],
        }
        payload_out = {"dataset": dataset_id, "createdAt": now_ms(), "ratios": ratios, "splits": split}
        self._write_json(dataset_dir / "meta" / "splits.json", payload_out)
        return payload_out

    def clean_dataset(self, dataset_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        """按帧数和迟到比例检测低质量 episode，可选择标记为 invalid。"""
        dataset_dir = self._dataset_path(dataset_id)
        info = self._read_json(dataset_dir / "meta" / "info.json")
        if not info:
            raise FileNotFoundError(dataset_id)
        min_frames = int(payload.get("minFrames", 1) or 1)
        max_late_ratio = float(payload.get("maxLateFrameRatio", 0.2) or 0.2)
        apply = bool(payload.get("apply", False))
        episodes = self._visible_episodes_for_dataset(dataset_dir, info)
        issues: list[dict[str, Any]] = []
        invalid_ids: set[str] = set()
        for episode in episodes:
            episode_id = str(episode.get("id", ""))
            frames = int(episode.get("frames", 0))
            late = int(episode.get("lateFrames", 0))
            reasons: list[str] = []
            if frames < min_frames:
                reasons.append(f"frames<{min_frames}")
            if frames > 0 and late / frames > max_late_ratio:
                reasons.append(f"late_ratio>{max_late_ratio:.3f}")
            if episode.get("status") == "invalid":
                reasons.append("already_invalid")
            if reasons:
                invalid_ids.add(episode_id)
                issues.append({"episodeId": episode_id, "reasons": reasons})
        applied = False
        if apply and invalid_ids and (dataset_dir / "meta" / "episodes.jsonl").exists():
            stored = self._read_episodes(dataset_dir)
            for episode in stored:
                if str(episode.get("id")) in invalid_ids:
                    episode["status"] = "invalid"
                    episode["updatedAt"] = now_ms()
            self._write_episodes(dataset_dir, stored)
            applied = True
        report = {"dataset": dataset_id, "apply": apply, "applied": applied, "issues": issues, "checked": len(episodes)}
        self._write_json(dataset_dir / "meta" / "cleaning_report.json", report)
        return report

    def push_dataset(self, dataset_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        """根据配置以 dry-run 或 LeRobot push_to_hub 方式处理数据集上传。"""
        requested_local_path = str(payload.get("localPath") or "").strip()
        dataset_dir = (
            Path(requested_local_path).expanduser()
            if requested_local_path
            else self._dataset_path(dataset_id)
        )
        info = self._read_json(dataset_dir / "meta" / "info.json")
        if not info:
            raise RuntimeError(f"local dataset path is invalid or missing meta/info.json: {dataset_dir}")
        config = self.settings.get_config()
        repo_id = str(payload.get("repoId") or "").strip()
        token = str(payload.get("token") or "").strip()
        private = bool(payload.get("private", False))
        dry_run = bool(payload.get("dryRun", True))
        push_enabled = bool(config.get("storage", {}).get("pushToHub", False))
        if not push_enabled or dry_run:
            return {
                "dataset": dataset_id,
                "localPath": str(dataset_dir),
                "repoId": repo_id,
                "pushed": False,
                "dryRun": True,
                "message": "Hub upload is dry-run or disabled; dataset remains local",
            }
        if not repo_id:
            raise RuntimeError("repoId is required when pushToHub is enabled")
        job_id = self._start_hub_push_job(dataset_id, repo_id, dataset_dir, token=token, private=private)
        return {
            "dataset": dataset_id,
            "localPath": str(dataset_dir),
            "repoId": repo_id,
            "queued": True,
            "jobId": job_id,
            "pushed": False,
            "dryRun": False,
            "private": private,
            "message": "Hub upload queued",
        }

    def _start_hub_push_job(
        self,
        dataset_id: str,
        repo_id: str,
        dataset_dir: Path,
        *,
        token: str,
        private: bool,
    ) -> str:
        job_id = uuid.uuid4().hex
        with self._hub_push_jobs_lock:
            self._hub_push_jobs[job_id] = {
                "status": "queued",
                "dataset": dataset_id,
                "repoId": repo_id,
                "localPath": str(dataset_dir),
                "private": private,
                "createdAt": now_ms(),
            }
        thread = Thread(
            target=self._run_hub_push_script,
            args=(job_id, dataset_id, repo_id, dataset_dir),
            kwargs={"token": token, "private": private},
            name=f"hf-upload-{dataset_id}",
            daemon=True,
        )
        thread.start()
        return job_id

    def _update_hub_push_job(self, job_id: str, **fields: Any) -> None:
        with self._hub_push_jobs_lock:
            current = self._hub_push_jobs.setdefault(job_id, {})
            current.update(fields)

    def _run_hub_push_script(
        self,
        job_id: str,
        dataset_id: str,
        repo_id: str,
        dataset_dir: Path,
        *,
        token: str,
        private: bool,
    ) -> None:
        repo_root = Path(__file__).resolve().parents[2]
        script_path = repo_root / "scripts" / "push_dataset_to_hub.py"
        command = [
            sys.executable,
            str(script_path),
            "--repo-id",
            repo_id,
            "--local-path",
            str(dataset_dir),
        ]
        if private:
            command.append("--private")
        env = os.environ.copy()
        if token:
            env["HF_TOKEN"] = token
            env["HUGGING_FACE_HUB_TOKEN"] = token
        self._update_hub_push_job(job_id, status="running", startedAt=now_ms())
        try:
            result = subprocess.run(command, cwd=str(repo_root), env=env, capture_output=True, text=True)
        except Exception as exc:  # noqa: BLE001
            self._update_hub_push_job(job_id, status="failed", finishedAt=now_ms(), error=str(exc))
            self.logs.error(
                "[LEROBOT]",
                f"hub upload job failed before script exit dataset={dataset_id} job={job_id}: {exc}",
            )
            return
        stdout = result.stdout[-4000:] if result.stdout else ""
        stderr = result.stderr[-4000:] if result.stderr else ""
        if result.returncode == 0:
            self._update_hub_push_job(
                job_id,
                status="succeeded",
                finishedAt=now_ms(),
                returncode=result.returncode,
                stdout=stdout,
                stderr=stderr,
            )
            self.logs.info("[LEROBOT]", f"hub upload job succeeded dataset={dataset_id} repo={repo_id} job={job_id}")
            return
        self._update_hub_push_job(
            job_id,
            status="failed",
            finishedAt=now_ms(),
            returncode=result.returncode,
            stdout=stdout,
            stderr=stderr,
        )
        self.logs.error(
            "[LEROBOT]",
            f"hub upload job failed dataset={dataset_id} repo={repo_id} job={job_id} returncode={result.returncode}",
        )

    # Keep request tokens transient by scoping them to this upload call.
    def _push_native_dataset_to_hub(self, dataset: Any, repo_id: str, *, token: str, private: bool) -> None:
        push_to_hub = dataset.push_to_hub
        kwargs: dict[str, Any] = {}
        accepts_any = True
        parameters: dict[str, inspect.Parameter] = {}
        try:
            parameters = dict(inspect.signature(push_to_hub).parameters)
            accepts_any = any(param.kind == inspect.Parameter.VAR_KEYWORD for param in parameters.values())
        except (TypeError, ValueError):
            parameters = {}

        def accepts(name: str) -> bool:
            return name in parameters or (not parameters and accepts_any)

        if accepts("private"):
            kwargs["private"] = private

        token_env_keys = ("HF_TOKEN", "HUGGING_FACE_HUB_TOKEN")
        previous_env = {key: os.environ.get(key) for key in token_env_keys}
        try:
            if token:
                for key in token_env_keys:
                    os.environ[key] = token
            push_to_hub(**kwargs)
        finally:
            for key, value in previous_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def update_episode(self, dataset_id: str, episode_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        """更新 episodes.jsonl 中指定 episode 的名称和状态。"""
        dataset_dir = self._dataset_path(dataset_id)
        episodes = self._read_episodes(dataset_dir)
        updated = False
        for episode in episodes:
            if str(episode.get("id")) != episode_id:
                continue
            name = str(payload.get("name", "")).strip()
            status = str(payload.get("status", "")).strip()
            if name:
                episode["name"] = name
            if status in {"valid", "review", "invalid"}:
                episode["status"] = status
            episode["updatedAt"] = now_ms()
            updated = True
            break
        if not updated:
            raise FileNotFoundError(episode_id)
        self._write_episodes(dataset_dir, episodes)
        return {"episode": episode_id}

    def delete_episode(self, dataset_id: str, episode_id: str) -> dict[str, Any]:
        """软删除指定 episode，并将其状态标记为 invalid。"""
        dataset_dir = self._dataset_path(dataset_id)
        episodes = self._read_episodes(dataset_dir)
        updated = False
        for episode in episodes:
            if str(episode.get("id")) == episode_id:
                episode["deleted"] = True
                episode["status"] = "invalid"
                episode["updatedAt"] = now_ms()
                updated = True
                break
        if not updated:
            raise FileNotFoundError(episode_id)
        self._write_episodes(dataset_dir, episodes)
        return {"deleted": episode_id}

    def resolve_file(self, dataset_id: str, relative_path: str) -> Path:
        """解析数据集内相对文件路径，防止越界访问并确认文件存在。"""
        dataset_dir = self._dataset_path(dataset_id)
        target = (dataset_dir / relative_path).resolve()
        root = dataset_dir.resolve()
        try:
            target.relative_to(root)
        except ValueError as exc:
            raise RuntimeError("file path is outside dataset") from exc
        if not target.exists() or not target.is_file():
            raise FileNotFoundError(relative_path)
        return target

    def resolve_frame_image(self, dataset_id: str, episode_id: str, camera: str, frame: int) -> bytes:
        """读取指定 episode、相机和帧的图像，并统一返回 JPEG bytes。"""
        if camera not in CAMERA_FEATURE_KEYS:
            raise FileNotFoundError(camera)
        dataset_dir = self._dataset_path(dataset_id)
        episodes = self._read_episodes(dataset_dir)
        if not episodes:
            episodes = self._native_episodes_from_meta(dataset_dir, self._read_json(dataset_dir / "meta" / "info.json"))
        episode = next((item for item in episodes if str(item.get("id")) == episode_id), None)
        if episode is None:
            raise FileNotFoundError(episode_id)
        if not bool(episode.get("native", False)):
            data_path = str(episode.get("dataPath", ""))
            feature_key = CAMERA_FEATURE_KEYS[camera]
            for item in self._fallback_frame_records(dataset_dir, data_path):
                if int(item.get("frame_index", -1)) != frame:
                    continue
                raw_path = item.get(feature_key)
                if isinstance(raw_path, str):
                    path = self.resolve_file(dataset_id, raw_path)
                    if path.suffix.lower() == ".mp4":
                        return self._decode_video_frame_to_jpeg(path, frame)
                    return path.read_bytes()
            raise FileNotFoundError(data_path)
        imports = self._native_imports()
        if imports is None:
            raise FileNotFoundError("lerobot")
        LeRobotDataset, np = imports
        try:
            dataset = self._open_native_dataset_for_read(dataset_id, dataset_dir, LeRobotDataset)
        except Exception:
            return self._native_video_frame_to_jpeg(dataset_dir, camera, frame)
        absolute_index = int(episode.get("datasetFromIndex") or 0) + max(0, int(frame))
        if absolute_index >= len(dataset):
            raise FileNotFoundError(str(frame))
        item = dataset[absolute_index]
        image = item.get(CAMERA_FEATURE_KEYS[camera])
        return self._encode_rgb_tensor_to_jpeg(image, np)

    def _native_video_frame_to_jpeg(self, dataset_dir: Path, camera: str, frame: int) -> bytes:
        feature_key = CAMERA_FEATURE_KEYS[camera]
        video_dir = dataset_dir / "videos" / feature_key
        videos = sorted(video_dir.glob("chunk-*/*.mp4"))
        if not videos:
            raise FileNotFoundError(camera)
        return self._decode_video_frame_to_jpeg(videos[0], frame)

    # 内部说明。
    def _new_sample_buffers(self, config: dict[str, Any]) -> dict[str, TimedRingBuffer]:
        """为所有采样源创建按各自频率配置容量的时间缓存。"""
        retention_s = self._sample_buffer_retention_s(config)
        return {
            source: TimedRingBuffer(
                retention_s=retention_s,
                maxlen=max(8, int(self._source_sample_rate_hz(source, config) * retention_s) + 4),
            )
            for source in SOURCE_KEYS
        }

    def _sample_buffer_retention_s(self, config: dict[str, Any]) -> float:
        """计算采样缓存保留时长，覆盖预热、消费延迟、抖动和回看窗口。"""
        storage = config.get("storage", {}) if isinstance(config.get("storage"), dict) else {}
        fps = max(1, self._record_fps_from_config(config))
        consumer_delay_s = self._positive_ratio(
            storage.get("maxConsumerLatencyS"),
            WRITE_QUEUE_MAX_FRAMES / fps,
        )
        jitter_s = self._positive_ratio(storage.get("maxSampleJitterS"), MAX_SAMPLE_JITTER_S)
        lookback_s = self._positive_ratio(storage.get("sampleLookbackWindowS"), SAMPLE_LOOKBACK_WINDOW_S)
        return max(
            RING_BUFFER_RETENTION_S,
            RECORDER_HARDWARE_WARMUP_S + consumer_delay_s + jitter_s + lookback_s,
        )

    def _native_writer_active(self) -> bool:
        """判断 native 写线程是否已接管一个打开的数据集。"""
        return getattr(self, "_writer_thread", None) is not None and getattr(self, "_native_dataset", None) is not None

    def _recording_config(self) -> dict[str, Any]:
        """返回会话开始时冻结的录制配置，缺省时读取当前配置。"""
        snapshot = getattr(self, "_recording_config_snapshot", None)
        if snapshot:
            return snapshot
        settings = getattr(self, "settings", None)
        return settings.get_config() if settings is not None else {}

    async def _episode_clock_pair(self, config: dict[str, Any]) -> tuple[float, float]:
        """返回 (HAL 采样时间, Python 调度时间)，采样时间优先来自 DDS steady_clock。"""
        schedule_now_s = time.monotonic()
        sample_clock_now_s = schedule_now_s
        hal = getattr(self, "hal", None)
        motion_state = getattr(hal, "motion_state", None)
        if self._real_hardware_mode(config) and callable(motion_state):
            try:
                state = await motion_state()
                sample_clock_now_s = self._source_sample_monotonic(state, schedule_now_s)
            except Exception as exc:  # noqa: BLE001
                warning = getattr(getattr(self, "logs", None), "warning", None)
                if callable(warning):
                    warning("[LEROBOT]", f"HAL steady clock unavailable, using scheduler clock: {exc}")
        return sample_clock_now_s, schedule_now_s

    async def _wait_for_episode_warmup(self) -> None:
        """等待采样预热完成后再让录制帧进入时间轴。"""
        delay_s = self._record_loop_start_monotonic_s - time.monotonic()
        if delay_s > 0.0:
            await asyncio.sleep(delay_s)

    async def _native_writer_command(self, kind: str) -> Any:
        """向 native 写线程发送控制命令，并异步等待执行结果。"""
        writer = self._writer_thread
        if writer is None:
            return None
        if not writer.is_alive():
            raise RuntimeError("native LeRobot writer is not running")
        future = writer.submit(kind)
        timeout_s = self._native_writer_command_timeout_seconds(kind)
        try:
            return await asyncio.wait_for(asyncio.shield(asyncio.wrap_future(future)), timeout=timeout_s)
        except TimeoutError as exc:
            raise RuntimeError(f"native LeRobot writer command timed out: {kind}") from exc

    def _native_writer_command_timeout_seconds(self, kind: str) -> float:
        if kind == "save_episode":
            return float(getattr(self, "_native_save_episode_timeout_s", NATIVE_SAVE_EPISODE_TIMEOUT_S))
        return float(getattr(self, "_native_writer_command_timeout_s", NATIVE_WRITER_COMMAND_TIMEOUT_S))

    async def _try_begin_native_dataset(self, config: dict[str, Any]) -> bool:
        """在写线程中打开或恢复 native 数据集，失败时记录错误原因。"""
        if not self._native_recording_requested():
            self._native_error = "native LeRobot disabled by APPSTATION_LEROBOT_NATIVE"
            return False
        preflight = self._native_preflight()
        if preflight:
            self._native_error = preflight
            return False
        try:
            total_frames = await self._native_writer_command("open")
            self._native_dataset = self._writer_thread
            self._native_total_frames_cached = int(total_frames or 0)
            return True
        except Exception as exc:  # noqa: BLE001
            self._native_dataset = None
            self._native_error = str(exc)
            return False

    async def _save_native_episode(self) -> None:
        """请求写线程保存当前 native episode 并更新累计帧数缓存。"""
        try:
            total_frames = await self._native_writer_command("save_episode")
            self._native_total_frames_cached = int(total_frames or 0)
        except Exception as exc:  # noqa: BLE001
            self._native_error = str(exc)
            raise DatasetSaveError(f"native LeRobot save_episode failed: {exc}") from exc

    async def _clear_native_episode_buffer(self) -> None:
        """请求写线程清空未保存的 native episode 缓冲区。"""
        try:
            await self._native_writer_command("clear_episode")
        except Exception as exc:  # noqa: BLE001
            self._native_error = str(exc)

    async def _finalize_native_dataset(self) -> None:
        """请求写线程 finalize native 数据集并清理服务侧引用。"""
        if self._writer_thread is None:
            self._native_dataset = None
            return
        try:
            await self._native_writer_command("finalize")
        except Exception as exc:  # noqa: BLE001
            self._native_error = str(exc)
        finally:
            self._native_dataset = None

    def _start_sampler_tasks_locked(self) -> None:
        """在持锁状态下启动每个硬件源对应的后台采样线程。"""
        self._sampler_stop_event.clear()
        for source in SOURCE_KEYS:
            thread = self._sampler_threads.get(source)
            if thread is None or not thread.is_alive():
                self._sampler_threads[source] = Thread(
                    target=self._sample_source_loop,
                    args=(source,),
                    name=f"dataset-sampler-{source}",
                    daemon=True,
                )
                self._sampler_threads[source].start()

    async def _stop_sampler_tasks(self) -> None:
        """通知所有采样线程停止，并等待线程退出。"""
        self._sampler_stop_event.set()
        threads = [(source, thread) for source, thread in self._sampler_threads.items() if thread.is_alive()]
        for _source, thread in threads:
            await asyncio.to_thread(thread.join, 1.0)
        alive = {source: thread for source, thread in self._sampler_threads.items() if thread.is_alive()}
        if alive:
            self._sampler_threads = alive
            message = f"record sampler threads did not stop: {', '.join(sorted(alive))}"
            self._native_error = message
            raise RuntimeError(message)
        self._sampler_threads = {}

    async def _drain_recording_queues(self) -> None:
        """等待组帧队列和写盘队列全部处理完成。"""
        assembly_queue = self._assembly_queue
        if assembly_queue is not None:
            await self._wait_recording_queue_drain(assembly_queue.join(), "frame assembly")
        await self._wait_recording_queue_drain(self._write_enqueue_idle.wait(), "writer enqueue")
        await self._wait_blocking_queue_drain(self._write_queue, "writer queue")

    def _recording_queue_drain_timeout_seconds(self) -> float:
        return float(getattr(self, "_recording_queue_drain_timeout_s", RECORDING_QUEUE_DRAIN_TIMEOUT_S))

    async def _wait_recording_queue_drain(self, awaitable: Awaitable[Any], label: str) -> None:
        try:
            await asyncio.wait_for(awaitable, timeout=self._recording_queue_drain_timeout_seconds())
        except TimeoutError as exc:
            message = f"recording queue drain timed out: {label}"
            self._native_error = message
            raise RuntimeError(message) from exc

    async def _wait_blocking_queue_drain(self, drain_queue: Any, label: str) -> None:
        timeout_s = self._recording_queue_drain_timeout_seconds()
        loop = asyncio.get_running_loop()
        unfinished_tasks = getattr(drain_queue, "unfinished_tasks", None)
        if isinstance(unfinished_tasks, int):
            deadline = loop.time() + timeout_s
            while int(getattr(drain_queue, "unfinished_tasks", 0)) > 0:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    message = f"recording queue drain timed out: {label}"
                    self._native_error = message
                    raise RuntimeError(message)
                await asyncio.sleep(min(0.01, remaining))
            return

        done = asyncio.Event()
        errors: list[BaseException] = []

        def wait_for_join() -> None:
            try:
                drain_queue.join()
            except BaseException as exc:  # noqa: BLE001
                errors.append(exc)
            finally:
                with contextlib.suppress(RuntimeError):
                    loop.call_soon_threadsafe(done.set)

        Thread(target=wait_for_join, name="dataset-recording-queue-drain", daemon=True).start()
        await self._wait_recording_queue_drain(done.wait(), label)
        if errors:
            raise errors[0]

    async def _stop_assembler_task(self) -> None:
        """排空组帧队列后取消组帧任务并清理队列引用。"""
        assembly_queue = self._assembly_queue
        if assembly_queue is not None:
            await self._wait_recording_queue_drain(assembly_queue.join(), "frame assembly")
        task = self._assembler_task
        if task is not None and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._assembler_task = None
        self._assembly_queue = None

    async def _stop_writer_task(self) -> None:
        # 停止 writer 前必须先排空队列，保证 metadata 的帧数和磁盘内容一致。
        """排空写入队列，发送停止哨兵并等待写线程退出。"""
        await self._wait_recording_queue_drain(self._write_enqueue_idle.wait(), "writer enqueue")
        await self._wait_blocking_queue_drain(self._write_queue, "writer queue")
        writer = self._writer_thread
        if writer is None:
            return
        try:
            self._write_queue.put_nowait(None)
        except queue.Full as exc:
            message = "recording queue drain timed out: writer stop"
            self._native_error = message
            raise RuntimeError(message) from exc
        await asyncio.to_thread(writer.join, 2.0)
        if writer.is_alive():
            message = "native LeRobot writer thread did not stop"
            self._native_error = message
            raise RuntimeError(message)
        self._writer_thread = None

    async def _rollback_failed_start(self) -> None:
        """Best-effort cleanup for failures after a record session begins activating."""
        try:
            await self.finish_session()
        except Exception as exc:  # noqa: BLE001
            self.logs.warning("[LEROBOT]", f"record session rollback failed: {exc}")

    def _sample_source_loop(self, source: str) -> None:
        """按源采样频率循环采样硬件数据并写入时间缓存。"""
        # Source samplers run in ordinary threads so slow hardware calls cannot
        # block the asyncio event loop that drives UI commands and status.
        sample_epoch_s = 0.0
        schedule_epoch_s = 0.0
        sample_index = 0
        while self._session_active and not self._sampler_stop_event.is_set():
            try:
                if getattr(self, "_samplers_paused", False):
                    self._sampler_stop_event.wait(0.02)
                    continue
                config = self._recording_config()
                start_s = self._sampler_start_monotonic_s
                schedule_start_s = getattr(self, "_sampler_schedule_start_s", 0.0) or start_s
                if start_s <= 0.0 or schedule_start_s <= 0.0:
                    self._sampler_stop_event.wait(0.01)
                    continue
                if start_s != sample_epoch_s or schedule_start_s != schedule_epoch_s:
                    sample_epoch_s = start_s
                    schedule_epoch_s = schedule_start_s
                    sample_index = 0
                    self._source_sample_indices[source] = 0
                rate_hz = self._source_sample_rate_hz(source, config)
                period_s = 1.0 / rate_hz
                relative_sample_s = self._source_sample_timestamp_s(source, sample_index, config)
                next_schedule_s = schedule_epoch_s + relative_sample_s
                now = time.monotonic()
                if now > next_schedule_s + period_s:
                    sample_index = max(sample_index, int(math.floor((now - schedule_epoch_s) * rate_hz)))
                    relative_sample_s = self._source_sample_timestamp_s(source, sample_index, config)
                    next_schedule_s = schedule_epoch_s + relative_sample_s
                if now < next_schedule_s:
                    if self._sampler_stop_event.wait(next_schedule_s - now):
                        return
                target_s = sample_epoch_s + self._source_sample_timestamp_s(source, sample_index, config)
                sample = self._sample_source_once_sync(source, config, target_s)
                if sample_epoch_s != self._sampler_start_monotonic_s:
                    continue
                self._sample_buffers.setdefault(source, TimedRingBuffer()).append(sample)
                sample_index += 1
                self._source_sample_indices[source] = sample_index
            except Exception as exc:  # noqa: BLE001
                self.logs.warning("[LEROBOT]", f"{source} sampler recovered: {exc}")
                self._sampler_stop_event.wait(0.1)

    def _source_sample_timestamp_s(self, source: str, sample_index: int, config: dict[str, Any]) -> float:
        """根据采样序号和源频率计算相对采样时间。"""
        return max(0, int(sample_index)) / self._source_sample_rate_hz(source, config)

    def _record_target_timestamp_s(self, frame_index: int) -> float:
        """根据帧号、预热时间和录制 FPS 计算目标帧时间。"""
        record_start_s = self._sampler_start_monotonic_s or self._episode_start_monotonic_s
        return record_start_s + RECORDER_HARDWARE_WARMUP_S + max(0, int(frame_index)) / max(1, self._record_fps_hz)

    def _record_schedule_timestamp_s(self, frame_index: int) -> float:
        """根据帧号和 Python 调度起点计算本机唤醒时间。"""
        record_start_s = self._record_loop_start_monotonic_s or self._episode_started_at
        return record_start_s + max(0, int(frame_index)) / max(1, self._record_fps_hz)

    def _frame_assembly_due_s(self, target_monotonic_s: float, config: dict[str, Any]) -> float:
        """计算目标帧在对齐延迟之后允许组帧的时间。"""
        return target_monotonic_s + self._alignment_delay_s(config)

    def _frame_assembly_schedule_due_s(self, frame_index: int, config: dict[str, Any]) -> float:
        """计算目标帧在对齐延迟之后的本机唤醒时间。"""
        return self._record_schedule_timestamp_s(frame_index) + self._alignment_delay_s(config)

    def _alignment_delay_s(self, config: dict[str, Any]) -> float:
        """读取配置中的源对齐延迟并转换为秒。"""
        storage = config.get("storage", {}) if isinstance(config.get("storage"), dict) else {}
        return self._positive_ratio(storage.get("alignmentDelayMs"), ALIGNMENT_DELAY_S * 1000.0) / 1000.0

    def _settle_timeout_s(self, config: dict[str, Any]) -> float:
        """读取组帧等待关键源追上目标时间的超时时长。"""
        storage = config.get("storage", {}) if isinstance(config.get("storage"), dict) else {}
        return self._positive_ratio(storage.get("settleTimeoutMs"), SETTLE_TIMEOUT_MS) / 1000.0

    async def _wait_for_critical_sources(
        self,
        config: dict[str, Any],
        target_monotonic_s: float,
        *,
        sources: tuple[str, ...] = CRITICAL_ALIGNMENT_SOURCE_KEYS,
    ) -> set[str]:
        """等待关键采样源至少有样本到达目标时间，超时返回缺失源。"""
        missing = self._sources_missing_at_or_after(sources, target_monotonic_s)
        timeout_s = self._settle_timeout_s(config)
        if not missing or timeout_s <= 0:
            for source in missing:
                self._source_warnings.append(f"{source} settle timeout")
            return missing
        deadline_s = time.monotonic() + timeout_s
        while missing:
            remaining_s = deadline_s - time.monotonic()
            if remaining_s <= 0:
                break
            await asyncio.sleep(min(0.002, remaining_s))
            missing = self._sources_missing_at_or_after(sources, target_monotonic_s)
        for source in missing:
            self._source_warnings.append(f"{source} settle timeout")
        return missing

    def _sources_missing_at_or_after(self, sources: tuple[str, ...], target_monotonic_s: float) -> set[str]:
        """统计尚未缓存到目标时间之后样本的源。"""
        missing: set[str] = set()
        for source in sources:
            buffer = self._sample_buffers.get(source)
            if buffer is None or not buffer.has_at_or_after(target_monotonic_s):
                missing.add(source)
        return missing

    def _sample_source_once_sync(self, source: str, config: dict[str, Any], target_s: float) -> TimedSample:
        """按源类型执行一次同步采样，并返回带时间戳的样本。"""
        if source == "hal":
            return asyncio.run(self._timed_source("hal", self.hal.motion_state(), target_s, record_quality=False))
        if source == "omega":
            return asyncio.run(self._timed_source("omega", self.hal.omega_state(), target_s, record_quality=False))
        if source == "force":
            return self._sample_force_source_sync(config, target_s)
        if source == "gripper":
            return self._gripper_source_sync(config, target_s, record_quality=False)
        camera = CAMERA_KEY_BY_SOURCE.get(source)
        if camera is not None:
            return self._sample_camera_source_sync(config, camera, target_s)
        return self._fallback_sample(source, target_s, f"{source} unsupported")

    def _sample_force_source_sync(self, config: dict[str, Any], target_s: float) -> TimedSample:
        """同步读取力传感器样本并记录采样耗时和时间戳。"""
        value: Any
        if not self._real_hardware_mode(config):
            sampled_at = time.monotonic()
            value = SimpleNamespace(
                ok=True,
                left=list(self.telemetry.force_left),
                right=list(self.telemetry.force_right),
                sample_monotonic_s=sampled_at,
            )
            return SourceSample("force", sampled_at, value, True, "", target_monotonic_s=target_s)
        started = time.monotonic()
        source = str(config.get("force", {}).get("source", "hkvl_serial")).lower()
        try:
            if source == "hkvl_serial":
                value = asyncio.run(self.hal.force_state())
                self._latest_force_state = dict(value)
                sides = value.get("sides", {}) if isinstance(value, dict) else {}
                left_status = sides.get("left", {}) if isinstance(sides, dict) else {}
                right_status = sides.get("right", {}) if isinstance(sides, dict) else {}
                value["ok"] = bool(left_status.get("healthy")) and bool(right_status.get("healthy"))
                if not value["ok"]:
                    value["message"] = "HKVL force sample is stale or unhealthy"
            else:
                value = self.hardware.force.sample(config)
            ok = bool(getattr(value, "ok", True) if not isinstance(value, dict) else value.get("ok", True))
            raw_message = getattr(value, "message", "") if not isinstance(value, dict) else value.get("message", "")
            message = "" if ok else str(raw_message)
        except Exception as exc:  # noqa: BLE001
            value = None
            ok = False
            message = f"force failed: {exc}"
        finished = time.monotonic()
        sample_time = self._source_sample_monotonic(value, finished) if ok else target_s
        return SourceSample(
            "force",
            sample_time,
            value,
            ok,
            message,
            target_monotonic_s=target_s,
            started_monotonic_s=started,
            finished_monotonic_s=finished,
            elapsed_ms=(finished - started) * 1000.0,
            stale=not ok,
        )

    def _sample_camera_source_sync(self, config: dict[str, Any], camera: str, target_s: float) -> TimedSample:
        """同步读取相机帧，失败时回退到最后一帧并记录缓存使用。"""
        source = CAMERA_SOURCE_KEYS[camera]
        feature_key = CAMERA_FEATURE_KEYS[camera]
        started = time.monotonic()
        if not self._real_hardware_mode(config):
            value = self._camera_placeholder_value(feature_key)
            finished = time.monotonic()
            return SourceSample(
                source,
                finished,
                value,
                True,
                "",
                target_monotonic_s=target_s,
                started_monotonic_s=started,
                finished_monotonic_s=finished,
                elapsed_ms=(finished - started) * 1000.0,
        )
        try:
            if not self._native_writer_active():
                raise RuntimeError("native LeRobot writer is not open")
            value, sampled_at = self._camera_recording_frame_with_time(config, camera)
            self._last_native_camera_frames[feature_key] = value
            self._record_camera_quality_sample(camera)
            ok = True
            message = ""
        except Exception as exc:  # noqa: BLE001
            ok = False
            message = f"{source} cache used: {exc}"
            value = self._last_camera_value(feature_key)
            sampled_at = None
        finished = time.monotonic()
        sample_time = sampled_at if sampled_at is not None else finished
        return SourceSample(
            source,
            sample_time,
            value,
            ok,
            message,
            target_monotonic_s=target_s,
            started_monotonic_s=started,
            finished_monotonic_s=finished,
            elapsed_ms=(finished - started) * 1000.0,
            timed_out=(finished - started) > self._source_timeout_s(source),
            stale=not ok,
            cache_used=not ok,
        )

    def _aligned_sample(self, source: str, target_s: float) -> TimedSample:
        """从源缓存中取目标时间附近样本，必要时生成 fallback 并记录质量。"""
        buffer = self._sample_buffers.get(source)
        max_skew_s = SOURCE_MAX_SKEW_S.get(source, 0.020)
        sample = buffer.nearest(target_s, max_skew_s) if buffer is not None else None
        if sample is None and buffer is not None:
            sample = buffer.nearest(target_s, math.inf)
            if sample is not None:
                sample = replace(
                    sample,
                    target_monotonic_s=target_s,
                    stale=True,
                    cache_used=sample.cache_used or source in CAMERA_KEY_BY_SOURCE,
                    message=sample.message or f"{source} stale",
                )
        if sample is None:
            sample = self._fallback_sample(source, target_s, f"{source} missing")
        elif sample.value is None:
            fallback = self._fallback_sample(source, target_s, sample.message or f"{source} missing")
            sample = replace(sample, value=fallback.value, stale=True)
        self._record_source_quality(sample, target_s, sample.elapsed_ms)
        return sample

    def _fallback_sample(self, source: str, target_s: float, message: str) -> TimedSample:
        """为缺失或失败的源生成 telemetry 或占位图像样本。"""
        value: Any = None
        if source == "hal":
            value = {"positions": list(self.telemetry.motion_positions), "pulses": self._latest_motion_pulses()}
        elif source == "force":
            value = SimpleNamespace(
                ok=True,
                left=list(self.telemetry.force_left),
                right=list(self.telemetry.force_right),
            )
        elif source == "gripper":
            value = list(self.telemetry.gripper_positions)
        elif source in CAMERA_KEY_BY_SOURCE:
            camera = CAMERA_KEY_BY_SOURCE[source]
            value = self._last_camera_value(CAMERA_FEATURE_KEYS[camera])
        return SourceSample(
            source,
            target_s,
            value,
            False,
            message,
            target_monotonic_s=target_s,
            stale=True,
            cache_used=source in CAMERA_KEY_BY_SOURCE,
        )

    def _latest_motion_pulses(self) -> list[float]:
        raw = getattr(self, "_last_motion_pulses", None)
        if isinstance(raw, list) and len(raw) == 12:
            try:
                return [float(value) for value in raw]
            except (TypeError, ValueError):
                pass
        return [0.0] * 12

    def _remember_motion_pulses(self, pulses: list[float]) -> None:
        if len(pulses) != 12:
            return
        self._last_motion_pulses = [float(value) for value in pulses]

    async def _record_loop(self) -> None:
        # 硬件采样由后台 sampler 产生，本循环只做时间对齐、组帧和入队。
        """按训练帧率调度目标帧，创建组帧任务并维护下一帧节拍。"""
        while self._session_active:
            try:
                async with self._lock:
                    recording = self._recording and getattr(self, "_accepting_frame_jobs", self._recording)
                    frame_index = self._queued_episode_frames
                    episode_index = self._episode_index
                    episode_generation = self._episode_generation
                    period_s = 1.0 / max(1, self._record_fps_hz)
                if not recording:
                    await asyncio.sleep(0.05)
                    continue
                target_tick = self._record_target_timestamp_s(frame_index)
                schedule_tick = self._record_schedule_timestamp_s(frame_index)
                now = time.monotonic()
                if now < schedule_tick:
                    await asyncio.sleep(schedule_tick - now)
                job = FrameAssemblyJob(
                    episode_index=episode_index,
                    episode_generation=episode_generation,
                    frame_index=frame_index,
                    target_monotonic_s=target_tick,
                    period_s=period_s,
                )
                await self._enqueue_assembly_job(job)
                next_schedule = self._record_schedule_timestamp_s(frame_index + 1)
                await asyncio.sleep(max(0.0, next_schedule - time.monotonic()))
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.logs.error("[LEROBOT]", f"record loop recovered: {exc}")
                await asyncio.sleep(0.2)

    async def _enqueue_assembly_job(self, job: FrameAssemblyJob) -> bool:
        """将当前帧组装任务放入队列，队列阻塞超时时停止录制。"""
        deadline_s = time.monotonic() + ASSEMBLY_QUEUE_PUT_TIMEOUT_S
        while True:
            async with self._lock:
                if not self._is_current_frame_job_locked(job):
                    return False
                assembly_queue = self._assembly_queue
                if assembly_queue is None:
                    self._stop_recording_for_backpressure_locked("frame assembly queue is not open")
                    return False
                try:
                    assembly_queue.put_nowait(job)
                except asyncio.QueueFull:
                    pass
                else:
                    self._mark_frame_job_queued_locked(job)
                    return True
            if time.monotonic() >= deadline_s:
                async with self._lock:
                    if self._is_current_frame_job_locked(job):
                        self._stop_recording_for_backpressure_locked("frame assembly queue backpressure timeout")
                self.logs.error("[LEROBOT]", "frame assembly queue backpressure timeout; current episode stopped")
                return False
            await asyncio.sleep(0.005)

    async def _frame_assembler_loop(self) -> None:
        """按队列顺序等待对齐时刻、组装帧并移交写线程。"""
        # Assembly is intentionally decoupled from writing: if disk/video work
        # stalls, backpressure is detected here before frames cross episodes.
        while self._session_active:
            assembly_queue = self._assembly_queue
            if assembly_queue is None:
                await asyncio.sleep(0.05)
                continue
            try:
                job = await assembly_queue.get()
            except asyncio.CancelledError:
                raise
            try:
                if not await self._frame_job_is_current(job):
                    continue
                config = self._recording_config()
                scheduled_tick = self._frame_assembly_schedule_due_s(job.frame_index, config)
                now = time.monotonic()
                if now < scheduled_tick:
                    await asyncio.sleep(scheduled_tick - now)
                if not await self._frame_job_is_current(job):
                    continue
                frame = await self._collect_frame(job.target_monotonic_s, frame_index=job.frame_index)
                capture_tick = time.monotonic()
                pending = PendingFrame(
                    episode_index=job.episode_index,
                    frame_index=job.frame_index,
                    timestamp=float(frame["timestamp"]),
                    frame=frame,
                )
                async with self._lock:
                    if not self._frame_job_belongs_to_current_episode_locked(job):
                        continue
                    self._quality_tracker.record_tick_locked(
                        job.target_monotonic_s,
                        scheduled_tick,
                        capture_tick,
                        job.period_s,
                    )
                await self._enqueue_pending_frame(pending, job)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self.logs.error("[LEROBOT]", f"frame assembler recovered: {exc}")
                await asyncio.sleep(0.05)
            finally:
                assembly_queue.task_done()

    async def _enqueue_pending_frame(self, pending: PendingFrame, job: FrameAssemblyJob) -> bool:
        """将已组装帧放入写盘队列，写入背压超时时停止录制。"""
        deadline_s = time.monotonic() + WRITE_QUEUE_PUT_TIMEOUT_S
        while True:
            async with self._lock:
                if not self._frame_job_belongs_to_current_episode_locked(job):
                    return False
                try:
                    self._write_queue.put_nowait(pending)
                except queue.Full:
                    pass
                else:
                    return True
            if time.monotonic() >= deadline_s:
                async with self._lock:
                    if self._frame_job_belongs_to_current_episode_locked(job):
                        self._stop_recording_for_backpressure_locked("writer queue backpressure timeout")
                self.logs.error("[LEROBOT]", "writer queue backpressure timeout; current episode stopped")
                return False
            await asyncio.sleep(0.005)

    async def _frame_job_is_current(self, job: FrameAssemblyJob) -> bool:
        """异步判断组帧任务是否仍属于当前正在录制的 episode。"""
        async with self._lock:
            return self._frame_job_belongs_to_current_episode_locked(job)

    def _is_current_frame_job_locked(self, job: FrameAssemblyJob) -> bool:
        """在持锁状态下校验组帧任务是否匹配当前帧序号。"""
        return (
            self._recording
            and getattr(self, "_accepting_frame_jobs", self._recording)
            and self._episode_index == job.episode_index
            and self._episode_generation == job.episode_generation
            and self._queued_episode_frames == job.frame_index
        )

    def _frame_job_belongs_to_current_episode_locked(self, job: FrameAssemblyJob) -> bool:
        """在持锁状态下校验组帧任务是否仍属于当前 episode。"""
        return (
            self._recording
            and self._episode_index == job.episode_index
            and self._episode_generation == job.episode_generation
        )

    def _mark_frame_job_queued_locked(self, job: FrameAssemblyJob) -> None:
        """在持锁状态下推进已排队帧计数并同步 telemetry 帧数。"""
        self._queued_episode_frames = job.frame_index + 1
        if time.monotonic() - self._last_telemetry_frame_update_s >= 0.1:
            self.telemetry.frame_count = max(self.telemetry.frame_count, self._queued_episode_frames)
            self._last_telemetry_frame_update_s = time.monotonic()

    def _stop_recording_for_backpressure_locked(self, message: str) -> None:
        """在队列背压异常时停止录制并登记质量告警。"""
        self._recording = False
        self._accepting_frame_jobs = False
        self.telemetry.recording = False
        self._episode_late_frames += 1
        self._source_warnings.append(message)
        self._native_error = message

    async def _collect_frame(
        self,
        target_monotonic_s: float | None = None,
        *,
        frame_index: int | None = None,
    ) -> dict[str, Any]:
        """等待关键源就绪后按目标时间组装一帧训练数据。"""
        config = self._recording_config()
        frame_index = self._episode_frames if frame_index is None else frame_index
        target_monotonic_s = (
            target_monotonic_s if target_monotonic_s is not None else self._record_target_timestamp_s(frame_index)
        )
        await self._wait_for_critical_sources(config, target_monotonic_s)
        return self._frame_assembler.assemble(config, target_monotonic_s, frame_index)

    def _gripper_source_sync(
        self,
        config: dict[str, Any],
        target_monotonic_s: float,
        *,
        record_quality: bool = True,
    ) -> SourceSample:
        """同步读取夹爪位置，优先使用 native teleop 缓存并记录陈旧状态。"""
        native_sample = self._latest_native_gripper_sample(config)
        if native_sample is not None:
            native_positions, sampled_at = native_sample
            if sampled_at <= 0.0:
                sampled_at = target_monotonic_s
            self._last_native_gripper_sample = (native_positions, sampled_at)
            sample = SourceSample(
                "gripper",
                sampled_at,
                list(native_positions),
                True,
                "",
                target_monotonic_s=target_monotonic_s,
                started_monotonic_s=sampled_at,
                finished_monotonic_s=sampled_at,
            )
            if record_quality:
                self._record_source_quality(sample, target_monotonic_s, 0.0)
            return sample
        if self._using_real_hal_native_teleop(config):
            cached_sample = getattr(self, "_last_native_gripper_sample", None)
            if cached_sample is not None:
                native_positions, sampled_at = cached_sample
                finished = time.monotonic()
                sample = SourceSample(
                    "gripper",
                    sampled_at,
                    list(native_positions),
                    False,
                    "native gripper status missing",
                    target_monotonic_s=target_monotonic_s,
                    started_monotonic_s=sampled_at,
                    finished_monotonic_s=finished,
                    stale=True,
                    cache_used=True,
                )
                if record_quality:
                    self._record_source_quality(sample, target_monotonic_s, 0.0)
                return sample
        if not self._real_hardware_mode(config):
            sampled_at = time.monotonic()
            sample = SourceSample(
                "gripper",
                sampled_at,
                list(self.telemetry.gripper_positions),
                True,
                "",
                target_monotonic_s=target_monotonic_s,
                started_monotonic_s=sampled_at,
                finished_monotonic_s=sampled_at,
            )
            if record_quality:
                self._record_source_quality(sample, target_monotonic_s, 0.0)
            return sample
        self._refresh_gripper_cache_sync(config)
        stale_after_s = self._positive_ratio(config.get("gripper", {}).get("sampleStaleMs"), 2500.0) / 1000.0
        stale_after_s = max(0.5, stale_after_s)
        last_sample_at = float(getattr(self.telemetry, "_last_gripper_sample_at", 0.0) or 0.0)
        age_s = time.monotonic() - last_sample_at if last_sample_at > 0 else math.inf
        ok = age_s <= stale_after_s
        message = "" if ok else f"gripper stale: {round(age_s, 3)}s"
        finished = time.monotonic()
        sample_time = self._gripper_sample_monotonic(target_monotonic_s, finished)
        sample = SourceSample(
            "gripper",
            sample_time,
            list(self.telemetry.gripper_positions),
            ok,
            message,
            target_monotonic_s=target_monotonic_s,
            started_monotonic_s=sample_time,
            finished_monotonic_s=finished,
            stale=not ok,
        )
        if record_quality:
            self._record_source_quality(sample, target_monotonic_s, 0.0)
        return sample

    def _latest_native_gripper_positions(self, config: dict[str, Any]) -> tuple[float, float] | None:
        """从 hal_native teleop 状态中提取最新左右夹爪当前位置。"""
        native_sample = self._latest_native_gripper_sample(config)
        return native_sample[0] if native_sample is not None else None

    def _latest_native_gripper_sample(self, config: dict[str, Any]) -> tuple[tuple[float, float], float] | None:
        """从 hal_native teleop 状态中提取夹爪位置和 native status 时间戳。"""
        teleop = getattr(self, "teleop", None)
        if teleop is None:
            return None
        status = teleop.status()
        native_status = status.get("nativeStatus") if isinstance(status, dict) else None
        if not isinstance(native_status, dict):
            return None
        grippers = native_status.get("grippers")
        if not isinstance(grippers, dict):
            return None
        left = grippers.get("left")
        right = grippers.get("right")
        if not isinstance(left, dict) or not isinstance(right, dict):
            return None
        left_position = self._coerce_float(left.get("positionMm"))
        right_position = self._coerce_float(right.get("positionMm"))
        if left_position is None or right_position is None:
            return None
        return (left_position, right_position), self._source_sample_monotonic(native_status, 0.0)

    async def _refresh_gripper_cache(self, config: dict[str, Any]) -> None:
        """在线程池中刷新夹爪位置缓存，避免阻塞事件循环。"""
        await asyncio.to_thread(self._refresh_gripper_cache_sync, config)

    def _refresh_gripper_cache_sync(self, config: dict[str, Any]) -> None:
        """调用 telemetry 提供的同步接口刷新夹爪位置缓存。"""
        refresh_gripper = getattr(self.telemetry, "refresh_gripper_positions", None)
        if callable(refresh_gripper):
            refresh_gripper(config, time.monotonic())

    async def _timed_source(
        self,
        source: str,
        awaitable: Any,
        target_monotonic_s: float,
        *,
        record_quality: bool = True,
    ) -> SourceSample:
        # 记录每个硬件源相对录制 tick 的时序，用于质量统计而不写入训练帧。
        """为异步硬件读取添加超时、耗时、时间戳和质量记录。"""
        started = time.monotonic()
        try:
            value = await asyncio.wait_for(awaitable, timeout=self._source_timeout_s(source))
            ok = True
            message = ""
            timed_out = False
        except TimeoutError:
            value = None
            ok = False
            message = f"{source} timeout"
            timed_out = True
        except Exception as exc:  # noqa: BLE001
            value = None
            ok = False
            message = f"{source} failed: {exc}"
            timed_out = False
        finished = time.monotonic()
        elapsed_ms = (finished - started) * 1000.0
        fallback_sample_time = finished if ok else target_monotonic_s
        sample = SourceSample(
            source,
            self._source_sample_monotonic(value, fallback_sample_time),
            value,
            ok,
            message,
            target_monotonic_s=target_monotonic_s,
            started_monotonic_s=started,
            finished_monotonic_s=finished,
            elapsed_ms=elapsed_ms,
            timed_out=timed_out,
            stale=not ok,
        )
        if record_quality:
            self._record_source_quality(sample, target_monotonic_s, elapsed_ms)
        return sample

    def _source_timeout_s(self, source: str) -> float:
        """返回指定采样源的读取超时时长。"""
        return SOURCE_TIMEOUT_S.get(source, 0.020)

    def _source_sample_rate_hz(self, source: str, config: dict[str, Any]) -> float:
        """根据源类型和配置计算采样频率。"""
        if source == "hal":
            motion = config.get("motion", {}) if isinstance(config.get("motion"), dict) else {}
            return max(self._positive_ratio(motion.get("motionThreadHz"), HAL_NATIVE_SAMPLE_HZ), 1.0)
        if source == "omega":
            teleop = config.get("teleop", {}) if isinstance(config.get("teleop"), dict) else {}
            interval_ms = self._positive_ratio(teleop.get("commandIntervalMs"), 0.0)
            default_hz = 1000.0 / interval_ms if interval_ms > 0 else OMEGA_NATIVE_SAMPLE_HZ
            return max(self._positive_ratio(teleop.get("omegaSampleHz"), default_hz), 1.0)
        if source == "force":
            return min(max(self._force_sample_hz_from_config(config), 1.0), 200.0)
        if source == "gripper":
            return min(max(self._positive_ratio(config.get("gripper", {}).get("sampleHz"), 30.0), 1.0), 60.0)
        if source in CAMERA_KEY_BY_SOURCE:
            return min(max(self._positive_ratio(config.get("cameras", {}).get("fps"), self._record_fps_hz), 1.0), 60.0)
        return min(max(float(self._record_fps_from_config(config)), 1.0), 60.0)

    def _force_values_from_sample(self, value: Any) -> tuple[list[float], list[float]] | None:
        """从 force 样本对象或字典中提取左右六轴力数据。"""
        if value is None:
            return None
        if isinstance(value, dict):
            left = value.get("left")
            right = value.get("right")
            ok = bool(value.get("ok", left is not None and right is not None))
        else:
            left = getattr(value, "left", None)
            right = getattr(value, "right", None)
            ok = bool(getattr(value, "ok", left is not None and right is not None))
        if not ok or not isinstance(left, list) or not isinstance(right, list):
            return None
        return (
            [float(item) for item in (left + [0.0] * 6)[:6]],
            [float(item) for item in (right + [0.0] * 6)[:6]],
        )

    def _source_sample_monotonic(self, value: Any, fallback_monotonic_s: float) -> float:
        """优先从样本中解析相对或绝对单调时间，失败时用 fallback。"""
        raw_relative = self._source_sample_relative_monotonic_s(value)
        if raw_relative is not None:
            return raw_relative
        raw_s = self._source_sample_absolute_monotonic_s(value)
        if raw_s is not None:
            return raw_s
        return fallback_monotonic_s

    def _source_sample_absolute_monotonic_s(self, value: Any) -> float | None:
        """从样本中解析驱动进程提供的绝对单调时间。"""
        if value is None:
            return None
        if isinstance(value, dict):
            candidates = (
                (value.get("sample_monotonic_s"), 1.0),
                (value.get("dds_stamp_monotonic_ms"), 0.001),
                (value.get("monotonicMs"), 0.001),
            )
        else:
            candidates = (
                (getattr(value, "sample_monotonic_s", None), 1.0),
                (getattr(value, "dds_stamp_monotonic_ms", None), 0.001),
                (getattr(value, "monotonicMs", None), 0.001),
            )
        for raw, scale in candidates:
            parsed = self._coerce_float(raw)
            if parsed is not None and parsed > 0:
                return parsed * scale
        return None

    def _source_sample_relative_monotonic_s(self, value: Any) -> float | None:
        """从样本中解析显式提供的相对单调时间。"""
        raw = value.get("monotonic_s") if isinstance(value, dict) else getattr(value, "monotonic_s", None)
        parsed = self._coerce_float(raw)
        return parsed if parsed is not None and parsed >= 0 else None

    def _gripper_sample_monotonic(self, fallback_monotonic_s: float, fallback_absolute_s: float) -> float:
        """从 telemetry 夹爪缓存中选择最新单调时间，缺失时回退。"""
        samples = getattr(self.telemetry, "gripper_samples", {}) or {}
        latest_s: float | None = None
        if isinstance(samples, dict):
            for sample in samples.values():
                raw = sample.get("monotonicMs") if isinstance(sample, dict) else None
                parsed = self._coerce_float(raw)
                if parsed is None or parsed <= 0:
                    continue
                absolute_s = parsed / 1000.0
                latest_s = absolute_s if latest_s is None else max(latest_s, absolute_s)
        if latest_s is not None:
            return latest_s
        return fallback_absolute_s if fallback_absolute_s > 0 else fallback_monotonic_s

    def _coerce_float(self, value: Any) -> float | None:
        """将输入转换为 float，无法转换时返回 None。"""
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    def _record_source_quality(self, sample: SourceSample, target_monotonic_s: float, elapsed_ms: float) -> None:
        # timeout 用 drop 边界，warning 用更严格的 skew 边界；这样慢但成功的源也会进入质量报告。
        """记录采样源偏差、耗时、丢帧、陈旧、缓存命中和连续失败统计。"""
        skew_ms = (sample.monotonic_s - target_monotonic_s) * 1000.0
        abs_skew_ms = abs(skew_ms)
        self._source_skews_ms.setdefault(sample.source, []).append(skew_ms)
        self._source_elapsed_ms.setdefault(sample.source, []).append(elapsed_ms)
        warning_threshold = SOURCE_WARNING_SKEW_MS.get(sample.source)
        if warning_threshold is not None and abs_skew_ms > warning_threshold:
            late_source_frames = getattr(self, "_late_source_frames", {})
            late_source_frames[sample.source] = late_source_frames.get(sample.source, 0) + 1
            self._late_source_frames = late_source_frames
        if sample.stale:
            stale_counts = getattr(self, "_stale_counts", {})
            stale_counts[sample.source] = stale_counts.get(sample.source, 0) + 1
            self._stale_counts = stale_counts
        if sample.cache_used:
            cache_counts = getattr(self, "_cache_counts", {})
            cache_counts[sample.source] = cache_counts.get(sample.source, 0) + 1
            self._cache_counts = cache_counts
            camera = CAMERA_KEY_BY_SOURCE.get(sample.source)
            if camera is not None:
                self._camera_drops[camera] = self._camera_drops.get(camera, 0) + 1
        drop_threshold = SOURCE_DROP_SKEW_MS.get(sample.source)
        if sample.ok and drop_threshold is not None and abs_skew_ms > drop_threshold:
            self._drop_counts[sample.source] = self._drop_counts.get(sample.source, 0) + 1
        if sample.ok:
            self._source_fail_streaks[sample.source] = 0
            return
        self._drop_counts[sample.source] = self._drop_counts.get(sample.source, 0) + 1
        streak = self._source_fail_streaks.get(sample.source, 0) + 1
        self._source_fail_streaks[sample.source] = streak
        if sample.message:
            self._source_warnings.append(sample.message)
        if streak >= 3:
            self._source_warnings.append(f"{sample.source} consecutive failures: {streak}")

    def _record_camera_quality_sample(self, camera: str) -> None:
        cached = getattr(self.telemetry, "_cached_cameras", [])
        for item in cached:
            key = item.get("key") if isinstance(item, dict) else getattr(item, "key", None)
            if key != camera:
                continue
            fps = self._coerce_float(item.get("fps") if isinstance(item, dict) else getattr(item, "fps", None))
            if fps is not None and fps > 0:
                previous = self._camera_min_fps.get(camera)
                self._camera_min_fps[camera] = fps if previous is None else min(previous, fps)
            backend = item.get("backend") if isinstance(item, dict) else getattr(item, "backend", None)
            worker_active = item.get("workerActive") if isinstance(item, dict) else getattr(item, "workerActive", None)
            if worker_active is False and isinstance(backend, str) and "fallback" in backend.lower():
                self._camera_worker_fallbacks.add(camera)
            return

    def _native_frame_payload(self, frame: dict[str, Any]) -> dict[str, Any]:
        """将内部帧结构转换为 LeRobotDataset.add_frame 需要的 native payload。"""
        native_frame = {
            "observation.state": self._np_float32(frame["observation.state"]),
            "observation.pulses": self._np_float32(frame["observation.pulses"]),
            "observation.force_left": self._np_float32(frame["observation.force_left"]),
            "observation.force_right": self._np_float32(frame["observation.force_right"]),
            "action": self._np_float32(frame["action"]),
            "task": self._task,
        }
        images = frame.get("images", {})
        if isinstance(images, dict):
            for feature_key in CAMERA_FEATURE_KEYS.values():
                image = images.get(feature_key)
                if image is None:
                    image = self._synthetic_camera_frame(feature_key)
                native_frame[feature_key] = image
        return native_frame

    def _mark_frame_written(self, frame: dict[str, Any]) -> None:
        """记录写线程已落盘帧数，并更新左右最大力值。"""
        self._episode_frames += 1
        self._max_force_left = max(self._max_force_left, self._force_norm(frame["observation.force_left"]))
        self._max_force_right = max(self._max_force_right, self._force_norm(frame["observation.force_right"]))

    def _recording_motion_positions(
        self,
        config: dict[str, Any],
        positions: list[float],
        pulses: list[float],
    ) -> list[float]:
        """根据录制原点脉冲将运动位置转换为相对 UI 坐标。"""
        origin = config.get("motion", {}).get("origin", {})
        if not isinstance(origin, dict) or len(pulses) != 12:
            return positions
        next_positions = (list(positions) + [0.0] * 12)[:12]
        relative_pulses = list(pulses)
        left_origin = self._origin_side_pulses(origin, "left")
        right_origin = self._origin_side_pulses(origin, "right")
        left_valid = bool(origin.get("leftValid", origin.get("valid", False)))
        right_valid = bool(origin.get("rightValid", origin.get("valid", False)))
        if left_valid and left_origin is not None:
            relative_pulses[:6] = [float(pulses[index]) - left_origin[index] for index in range(6)]
        if right_valid and right_origin is not None:
            relative_pulses[6:12] = [float(pulses[index + 6]) - right_origin[index] for index in range(6)]
        if not left_valid and not right_valid:
            return next_positions
        relative_positions = pulses_to_ui_state(relative_pulses, config)
        if left_valid and left_origin is not None:
            next_positions[:6] = relative_positions[:6]
        if right_valid and right_origin is not None:
            next_positions[6:12] = relative_positions[6:12]
        return next_positions

    def _origin_side_pulses(self, origin: dict[str, Any], side: str) -> list[float] | None:
        """从运动原点配置中读取指定侧的六轴脉冲基准。"""
        key = "leftPulse" if side == "left" else "rightPulse"
        raw = origin.get(key)
        if not isinstance(raw, list) or len(raw) < 6:
            return None
        try:
            return [float(value) for value in raw[:6]]
        except (TypeError, ValueError):
            return None

    def _begin_episode_locked(
        self,
        *,
        sample_clock_now_s: float | None = None,
        schedule_now_s: float | None = None,
    ) -> None:
        """初始化新 episode 的时间轴、缓存、计数器、质量统计和录制状态。"""
        # 每个 episode 独立统计质量指标，保存或丢弃时可以精确回滚。
        schedule_now_s = time.monotonic() if schedule_now_s is None else schedule_now_s
        sample_clock_now_s = schedule_now_s if sample_clock_now_s is None else sample_clock_now_s
        sampler_start_s = sample_clock_now_s + SAMPLER_START_LEAD_S
        sampler_schedule_start_s = schedule_now_s + SAMPLER_START_LEAD_S
        record_start_s = sampler_start_s + RECORDER_HARDWARE_WARMUP_S
        record_schedule_start_s = sampler_schedule_start_s + RECORDER_HARDWARE_WARMUP_S
        self._episode_generation += 1
        self._sampler_start_monotonic_s = sampler_start_s
        self._sampler_schedule_start_s = sampler_schedule_start_s
        self._record_loop_start_monotonic_s = record_schedule_start_s
        self._episode_started_at = record_schedule_start_s
        self._episode_start_monotonic_s = record_start_s
        self._episode_source_time0_s = RECORDER_HARDWARE_WARMUP_S
        self._episode_frames = 0
        self._queued_episode_frames = 0
        self._episode_late_frames = 0
        self._camera_drops = {key: 0 for key in CAMERA_KEYS}
        self._camera_min_fps = {}
        self._camera_worker_fallbacks = set()
        self._tick_target_monotonic_s = 0.0
        self._tick_capture_monotonic_s = 0.0
        self._tick_skews_ms = []
        self._last_telemetry_frame_update_s = 0.0
        self._drop_counts = {key: 0 for key in (*CAMERA_KEYS, *SOURCE_KEYS)}
        self._stale_counts = {key: 0 for key in SOURCE_KEYS}
        self._cache_counts = {key: 0 for key in SOURCE_KEYS}
        self._late_source_frames = {}
        self._source_skews_ms = {key: [] for key in SOURCE_KEYS}
        self._source_elapsed_ms = {key: [] for key in SOURCE_KEYS}
        self._source_fail_streaks = {key: 0 for key in SOURCE_KEYS}
        self._sample_buffers = self._new_sample_buffers(self._recording_config())
        self._source_sample_indices = {key: 0 for key in SOURCE_KEYS}
        self._source_warnings = []
        self._last_native_gripper_sample = None
        self._max_force_left = 0.0
        self._max_force_right = 0.0
        if not self._native_writer_active():
            raise DatasetSaveError(self._native_required_message())
        self._native_dataset_from_index = self._native_total_frames_cached
        self._samplers_paused = False
        self._recording = True
        self._safety_interrupted = False
        self._accepting_frame_jobs = True

    def _finalize_episode_locked(self, *, status: str, deleted: bool) -> dict[str, Any]:
        """生成并写入 episode 元数据，更新 native 索引和数据集信息。"""
        dataset_dir = self._require_dataset_dir()
        duration_s = max(0.0, time.monotonic() - self._episode_started_at)
        native = self._native_writer_active()
        if not native and not deleted:
            raise DatasetSaveError(self._native_required_message())
        episode_id = f"episode_{self._episode_index:06d}"
        skew = self._skew_stats()
        source_skew = self._source_skew_stats()
        config_snapshot = self._recording_config()
        # 每个 episode 独立统计质量指标，保存或丢弃时可以精确回滚。
        episode = {
            "id": episode_id,
            "name": episode_id,
            "task": self._task,
            "status": status,
            "deleted": deleted,
            "episodeIndex": self._episode_index,
            "frames": self._episode_frames,
            "fps": self._record_fps_hz,
            "durationS": round(duration_s, 3),
            "createdAt": now_ms(),
            "dataPath": "",
            "datasetFromIndex": self._native_dataset_from_index if native else None,
            "datasetToIndex": self._native_dataset_from_index + self._episode_frames if native else None,
            "native": native,
            "lateFrames": self._episode_late_frames,
            "cameraDrops": dict(self._camera_drops),
            "cameraMinFps": dict(getattr(self, "_camera_min_fps", {})),
            "cameraWorkerFallbacks": sorted(getattr(self, "_camera_worker_fallbacks", set())),
            "dropCounts": dict(self._drop_counts),
            "staleCounts": dict(self._stale_counts),
            "cacheCounts": dict(self._cache_counts),
            "maxSkewMs": skew["maxSkewMs"],
            "avgSkewMs": skew["avgSkewMs"],
            "jitterMs": skew["jitterMs"],
            "sourceMaxSkewMs": source_skew["maxSkewMs"],
            "sourceAvgSkewMs": source_skew["avgSkewMs"],
            "sourceJitterMs": source_skew["jitterMs"],
            "maxForceLeft": round(self._max_force_left, 6),
            "maxForceRight": round(self._max_force_right, 6),
            "warnings": self._quality_warnings(),
            "motionOrigin": self._episode_motion_origin_snapshot(config_snapshot),
            "motionCalibration": self._motion_calibration_snapshot(config_snapshot),
        }
        episodes = self._read_episodes(dataset_dir)
        episodes = [item for item in episodes if str(item.get("id")) != episode_id]
        episodes.append(episode)
        self._write_episodes(dataset_dir, episodes)
        info_path = dataset_dir / "meta" / "info.json"
        info = self._read_json(info_path)
        if info:
            if native:
                info["updatedAt"] = now_ms()
                self._write_appstation_info(dataset_dir, config_snapshot)
        self._episode_index += 1
        return episode

    # 原地位置快照
    def _episode_motion_origin_snapshot(self, config_snapshot: dict[str, Any]) -> dict[str, Any]:
        """从配置中截取当前 episode 使用的运动原点快照。"""
        motion = config_snapshot.get("motion", {}) if isinstance(config_snapshot.get("motion"), dict) else {}
        origin = motion.get("origin", {}) if isinstance(motion.get("origin"), dict) else {}
        return {
            "leftValid": bool(origin.get("leftValid", origin.get("valid", False))),
            "rightValid": bool(origin.get("rightValid", origin.get("valid", False))),
            "valid": bool(origin.get("valid", False)),
            "leftPulse": list(origin.get("leftPulse", [0.0] * 6))[:6],
            "rightPulse": list(origin.get("rightPulse", [0.0] * 6))[:6],
            "updatedAt": int(origin.get("updatedAt", 0) or 0),
            "positionSource": motion.get("positionSource", ""),
            "configHash": stable_config_hash(config_snapshot),
        }

    def _motion_calibration_snapshot(self, config_snapshot: dict[str, Any]) -> dict[str, Any]:
        """截取位姿换算和手动控制会用到的运动标定。"""
        motion = config_snapshot.get("motion", {}) if isinstance(config_snapshot.get("motion"), dict) else {}
        kinematics = motion.get("kinematics", {}) if isinstance(motion.get("kinematics"), dict) else {}
        teleop = config_snapshot.get("teleop", {}) if isinstance(config_snapshot.get("teleop"), dict) else {}
        signed_pulse_per_unit = motion_pulse_per_unit(config_snapshot)
        left_signed = [float(value) for value in signed_pulse_per_unit[:6]]
        right_signed = [float(value) for value in signed_pulse_per_unit[6:]]

        def float_axis_array(raw: Any, fallback: list[float] | tuple[float, ...]) -> list[float]:
            values = raw if isinstance(raw, list) and len(raw) >= 6 else fallback
            try:
                return [float(values[index]) for index in range(6)]
            except (TypeError, ValueError, IndexError):
                return [float(fallback[index]) for index in range(6)]

        def int_axis_array(raw: Any, fallback: list[int] | tuple[int, ...]) -> list[int]:
            values = raw if isinstance(raw, list) and len(raw) >= 6 else fallback
            try:
                return [int(values[index]) for index in range(6)]
            except (TypeError, ValueError, IndexError):
                return [int(fallback[index]) for index in range(6)]

        def text_axis_array(raw: Any, fallback: list[str] | tuple[str, ...]) -> list[str]:
            values = raw if isinstance(raw, list) and len(raw) >= 6 else fallback
            return [str(values[index]) for index in range(6)]

        return {
            "kinematics": {
                "source": str(kinematics.get("source", ICF_KINEMATICS_DEFAULTS.get("source", ""))),
                "axisOrder": text_axis_array(kinematics.get("axisOrder"), MOTION_AXIS_NAMES),
                "axisUnitSpec": text_axis_array(
                    kinematics.get("axisUnitSpec"),
                    ICF_KINEMATICS_DEFAULTS["axisUnitSpec"],
                ),
                "leftAxisMap": int_axis_array(kinematics.get("leftAxisMap"), ICF_KINEMATICS_DEFAULTS["leftAxisMap"]),
                "rightAxisMap": int_axis_array(
                    kinematics.get("rightAxisMap"),
                    ICF_KINEMATICS_DEFAULTS["rightAxisMap"],
                ),
                "leftPhysicalAxis": int_axis_array(
                    kinematics.get("leftPhysicalAxis"),
                    ICF_KINEMATICS_DEFAULTS["leftPhysicalAxis"],
                ),
                "rightPhysicalAxis": int_axis_array(
                    kinematics.get("rightPhysicalAxis"),
                    ICF_KINEMATICS_DEFAULTS["rightPhysicalAxis"],
                ),
                "leftPulsePerUnit": float_axis_array(
                    kinematics.get("leftPulsePerUnit"),
                    [abs(value) for value in left_signed],
                ),
                "rightPulsePerUnit": float_axis_array(
                    kinematics.get("rightPulsePerUnit"),
                    [abs(value) for value in right_signed],
                ),
                "leftDirectionSign": int_axis_array(
                    kinematics.get("leftDirectionSign"),
                    ICF_KINEMATICS_DEFAULTS["leftDirectionSign"],
                ),
                "rightDirectionSign": int_axis_array(
                    kinematics.get("rightDirectionSign"),
                    ICF_KINEMATICS_DEFAULTS["rightDirectionSign"],
                ),
                "leftSignedPulsePerUnit": left_signed,
                "rightSignedPulsePerUnit": right_signed,
                "syncActionPulseCoeff": bool(
                    kinematics.get("syncActionPulseCoeff", ICF_KINEMATICS_DEFAULTS.get("syncActionPulseCoeff", False))
                ),
                "updatedAt": str(kinematics.get("updatedAt", ICF_KINEMATICS_DEFAULTS.get("updatedAt", ""))),
            },
            "teleop": {
                "strategyVersion": str(teleop.get("strategyVersion", ICF_TELEOP_DEFAULTS.get("strategyVersion", ""))),
                "mappingMode": str(teleop.get("mappingMode", ICF_TELEOP_DEFAULTS.get("mappingMode", ""))),
                "leftImpulseCoeff": float_axis_array(
                    teleop.get("leftImpulseCoeff"),
                    ICF_TELEOP_DEFAULTS["leftImpulseCoeff"],
                ),
                "rightImpulseCoeff": float_axis_array(
                    teleop.get("rightImpulseCoeff"),
                    ICF_TELEOP_DEFAULTS["rightImpulseCoeff"],
                ),
                "leftDirectionSign": int_axis_array(
                    teleop.get("leftDirectionSign"),
                    ICF_TELEOP_DEFAULTS["leftDirectionSign"],
                ),
                "rightDirectionSign": int_axis_array(
                    teleop.get("rightDirectionSign"),
                    ICF_TELEOP_DEFAULTS["rightDirectionSign"],
                ),
                "syncImpulseCoeffFromKinematics": bool(
                    teleop.get(
                        "syncImpulseCoeffFromKinematics",
                        ICF_TELEOP_DEFAULTS.get("syncImpulseCoeffFromKinematics", False),
                    )
                ),
            },
            "stateUnitSpec": list(LEROBOT_STATE_UNIT_SPEC),
            "configHash": stable_config_hash(config_snapshot),
        }

    def _mark_saved_episode_deleted_locked(self, episode: dict[str, Any]) -> None:
        """将最近保存的 episode 在元数据中标记为删除和 invalid。"""
        dataset_dir = self._require_dataset_dir()
        episode_id = str(episode.get("id", ""))
        episodes = self._read_episodes(dataset_dir)
        for item in episodes:
            if str(item.get("id", "")) == episode_id:
                item["deleted"] = True
                item["status"] = "invalid"
                item["updatedAt"] = now_ms()
                break
        self._write_episodes(dataset_dir, episodes)

    def _write_appstation_info(self, dataset_dir: Path, config: dict[str, Any]) -> None:
        """写入 AppStation 扩展元数据，记录硬件、格式和录制参数。"""
        path = dataset_dir / "meta" / "appstation_info.json"
        info = self._read_json(path)
        payload = {
            "name": str(info.get("name") or self._dataset_name),
            "status": str(info.get("status", "local")) if info else "local",
            "format": "lerobot-v3-native",
            "codebase_version": "v3.0",
            "nativeLeRobotAvailable": True,
            "useVideos": self._native_use_videos,
            "vcodec": self._native_vcodec(),
            "streamingEncoding": True,
            "recording": {
                "fps": self._record_fps_hz,
                "forceSampleHz": self._force_sample_hz,
                "alignment": (
                    "source samplers record host monotonic sample times; "
                    "record frames align at sampler_start_s + warmup_s + frame_index / record_fps; "
                    "assembly waits alignment_delay_ms before settling critical source buffers"
                ),
                "alignmentDelayMs": round(self._alignment_delay_s(config) * 1000.0, 3),
                "settleTimeoutMs": round(self._settle_timeout_s(config) * 1000.0, 3),
            },
            "sessionOrigin": self._episode_motion_origin_snapshot(config),
            "createdAt": int(info.get("createdAt", now_ms())) if info else now_ms(),
            "updatedAt": now_ms(),
            "hardware": {
                "cameras": config.get("cameras", {}),
                "cameraResolutions": self._camera_resolution_summary_from_config(config),
                "force": self._force_metadata(config),
                "motion": self._motion_calibration_snapshot(config),
            },
        }
        self._write_json(path, payload)

    def _force_metadata(self, config: dict[str, Any]) -> dict[str, Any]:
        force = config.get("force", {}) if isinstance(config.get("force"), dict) else {}
        source = str(force.get("source", "hkvl_serial")).lower()
        if source != "hkvl_serial":
            return {
                "source": "nidaq",
                "leftIp": force.get("leftIp"),
                "rightIp": force.get("rightIp"),
                "sampleHz": force.get("sampleHz"),
            }
        serial = force.get("serial", {}) if isinstance(force.get("serial"), dict) else {}
        latest = getattr(self, "_latest_force_state", {})
        sides = latest.get("sides", {}) if isinstance(latest, dict) else {}
        left = sides.get("left", {}) if isinstance(sides, dict) else {}
        right = sides.get("right", {}) if isinstance(sides, dict) else {}
        force_payload = hal_force_config_payload(config)
        return {
            "source": source,
            "protocol": serial.get("protocol"),
            "serial": deepcopy(serial),
            "measurementSampleHz": serial.get("expectedSampleHz"),
            "recordSampleHz": self._force_sample_hz,
            "axisSign": {
                "left": list(left.get("axisSign", force_payload["leftAxisSign"])),
                "right": list(right.get("axisSign", force_payload["rightAxisSign"])),
            },
            "tareBias": {
                "left": list(left.get("tareBias", [0.0] * 6)),
                "right": list(right.get("tareBias", [0.0] * 6)),
            },
            "sensorTareBias": {
                "left": list(left.get("sensorTareBias", [0.0] * 6)),
                "right": list(right.get("sensorTareBias", [0.0] * 6)),
            },
            "mapping": {
                side: list(force.get("compliance", {}).get(side, {}).get("matrix", []))
                for side in ("left", "right")
            },
            "compliance": deepcopy(force.get("compliance", {})),
            "runtimeCompliance": deepcopy(
                latest.get("compliance", {}) if isinstance(latest, dict) else {}
            ),
        }

    def _create_native_dataset_metadata(self, dataset_dir: Path, config: dict[str, Any]) -> bool:
        """预检依赖后创建 native LeRobot 数据集并写入 AppStation 元数据。"""
        if not self._native_recording_requested():
            self._native_error = "native LeRobot disabled by APPSTATION_LEROBOT_NATIVE"
            return False
        preflight = self._native_preflight()
        if preflight:
            self._native_error = preflight
            return False
        imports = self._native_imports()
        if imports is None:
            self._native_error = "lerobot[dataset] is not installed in backend runtime"
            return False
        if dataset_dir.exists() and any(dataset_dir.iterdir()):
            self._native_error = "dataset directory already contains files"
            return False
        LeRobotDataset, _np = imports
        repo_id = f"local/{dataset_dir.name}"
        previous_use_videos = self._native_use_videos
        self._native_use_videos = self._native_use_videos_requested()
        try:
            if dataset_dir.exists():
                dataset_dir.rmdir()
            dataset = LeRobotDataset.create(
                repo_id=repo_id,
                fps=self._record_fps_from_config(config),
                features=self._native_features(config),
                root=dataset_dir,
                robot_type="dual_arm_micro_assembly",
                use_videos=self._native_use_videos,
                metadata_buffer_size=1,
                **self._native_writer_kwargs(),
            )
            self._configure_native_chunk_settings(dataset)
            dataset.finalize()
            self._write_appstation_info(dataset_dir, config)
            return True
        except Exception as exc:  # noqa: BLE001
            self._native_error = str(exc)
            return False
        finally:
            self._native_use_videos = previous_use_videos

    def _open_native_dataset_for_writer(self) -> Any:
        # 录制时由 writer 线程打开 LeRobot native dataset。
        """为写线程创建或恢复 native LeRobot 数据集实例。"""
        config = self._recording_config()
        if not self._native_recording_requested():
            raise RuntimeError("native LeRobot disabled by APPSTATION_LEROBOT_NATIVE")
        preflight = self._native_preflight()
        if preflight:
            raise RuntimeError(preflight)
        imports = self._native_imports()
        if imports is None:
            raise RuntimeError("lerobot[dataset] is not installed in backend runtime")
        if self._dataset_dir is None:
            raise RuntimeError("record dataset is not initialized")
        LeRobotDataset, _np = imports
        dataset_dir = self._dataset_dir
        repo_id = f"local/{self._dataset_id}"
        self._native_use_videos = self._native_use_videos_requested()
        try:
            self._cleanup_native_tmp_dirs(dataset_dir)
            if self._is_native_dataset(dataset_dir, self._read_json(dataset_dir / "meta" / "info.json")):
                if self._native_dataset_is_empty(dataset_dir):
                    # 空的原生目录可能来自上次初始化失败，重建可以修复损坏的 meta。
                    app_info = self._read_json(dataset_dir / "meta" / "appstation_info.json")
                    shutil.rmtree(dataset_dir)
                    dataset = LeRobotDataset.create(
                        repo_id=repo_id,
                        fps=self._record_fps_hz,
                        features=self._native_features(config),
                        root=dataset_dir,
                        robot_type="dual_arm_micro_assembly",
                        use_videos=self._native_use_videos,
                        metadata_buffer_size=1,
                        **self._native_writer_kwargs(),
                    )
                    if app_info:
                        self._write_json(dataset_dir / "meta" / "appstation_info.json", app_info)
                else:
                    # 每个 episode 独立统计质量指标，保存或丢弃时可以精确回滚。
                    dataset = LeRobotDataset.resume(
                        repo_id=repo_id,
                        root=dataset_dir,
                        **self._native_writer_kwargs(),
                    )
                    self._sync_recording_shape_from_native_info(dataset_dir)
            elif dataset_dir.exists() and any(dataset_dir.iterdir()):
                self._native_error = "dataset directory already contains non-native files"
                raise RuntimeError(self._native_error)
            else:
                if dataset_dir.exists():
                    dataset_dir.rmdir()
                dataset = LeRobotDataset.create(
                    repo_id=repo_id,
                    fps=self._record_fps_hz,
                    features=self._native_features(config),
                    root=dataset_dir,
                    robot_type="dual_arm_micro_assembly",
                    use_videos=self._native_use_videos,
                    metadata_buffer_size=1,
                    **self._native_writer_kwargs(),
                )
            self._configure_native_chunk_settings(dataset)
            return dataset
        except Exception as exc:  # noqa: BLE001
            self._native_error = str(exc)
            raise

    def _native_required_message(self) -> str:
        """组合 native 数据集不可用时给前端或异常使用的错误信息。"""
        reason = self._native_error or "native LeRobot dataset initialization failed"
        return f"native LeRobot dataset is required; {reason}"

    def _native_dataset_is_empty(self, dataset_dir: Path) -> bool:
        """检查 native 数据集目录是否还没有 parquet episode 数据。"""
        data_dir = dataset_dir / "data"
        episode_meta_dir = dataset_dir / "meta" / "episodes"
        return (
            not any(data_dir.glob("chunk-*/*.parquet"))
            and not any(episode_meta_dir.glob("chunk-*/*.parquet"))
            and not self._read_episodes(dataset_dir)
        )

    def _cleanup_native_tmp_dirs(self, dataset_dir: Path) -> None:
        if not dataset_dir.exists():
            return
        for item in dataset_dir.glob("tmp*"):
            if item.is_dir() and any(item.glob("*_streaming.mp4")):
                shutil.rmtree(item, ignore_errors=True)

    def _native_features(self, config: dict[str, Any]) -> dict[str, Any]:
        # 这些 feature 名称需要和 LeRobot 数据集字段保持稳定，前后端按它们读取图像。
        """构建 LeRobot native 数据集的状态、动作、力和相机 feature 定义。"""
        image_dtype = "video" if self._native_use_videos else "image"
        features: dict[str, Any] = {
            "observation.state": {"dtype": "float32", "shape": (14,), "names": list(STATE_FEATURE_NAMES)},
            "observation.pulses": {"dtype": "float32", "shape": (12,), "names": list(PULSE_FEATURE_NAMES)},
            "observation.force_left": {"dtype": "float32", "shape": (6,), "names": list(FORCE_FEATURE_NAMES)},
            "observation.force_right": {"dtype": "float32", "shape": (6,), "names": list(FORCE_FEATURE_NAMES)},
            "action": {"dtype": "float32", "shape": (14,), "names": list(STATE_FEATURE_NAMES)},
        }
        for key, feature_key in CAMERA_FEATURE_KEYS.items():
            width, height = CAMERA_CAPTURE_SIZES[key]
            features[feature_key] = {
                "dtype": image_dtype,
                "shape": (height, width, 3),
                "names": ["height", "width", "channels"],
            }
        return features

    def _native_imports(self) -> tuple[Any, Any] | None:
        """动态导入 LeRobotDataset 和 numpy，缺失时返回 None。"""
        try:
            module = importlib.import_module("lerobot.datasets.lerobot_dataset")
            np = importlib.import_module("numpy")
        except Exception:
            return None
        return module.LeRobotDataset, np

    def _native_preflight(self) -> str:
        """检查 native 录制依赖及视频编码器是否可用。"""
        imports = self._native_imports()
        if imports is None:
            return "lerobot[dataset] is not installed in backend runtime"
        if self._native_use_videos_requested():
            try:
                av = importlib.import_module("av")
            except Exception as exc:  # noqa: BLE001
                return f"PyAV is required for native LeRobot video recording: {exc}"
            codec = self._native_vcodec().lower()
            if codec in {"av1", "libsvtav1", "svt_av1"}:
                try:
                    av.Codec("libsvtav1", "w")
                except Exception as exc:  # noqa: BLE001
                    return f"libsvtav1 encoder is unavailable for native LeRobot video recording: {exc}"
        return ""

    def _native_recording_requested(self) -> bool:
        """读取环境变量判断是否允许 native LeRobot 录制。"""
        value = os.environ.get("APPSTATION_LEROBOT_NATIVE", "auto").strip().lower()
        return value not in {"0", "false", "off", "no"}

    def _native_use_videos_requested(self) -> bool:
        """返回 native 数据集是否使用视频字段存储相机数据。"""
        return True

    def _native_writer_kwargs(self) -> dict[str, Any]:
        """生成创建或恢复 native 数据集时传给写入器的编码参数。"""
        return {
            "batch_encoding_size": 1,
            "vcodec": self._native_vcodec(),
            "streaming_encoding": True,
            "encoder_queue_maxsize": self._native_encoder_queue_maxsize(),
            "encoder_threads": self._native_encoder_threads(),
        }

    def _configure_native_chunk_settings(self, dataset: Any) -> None:
        """配置 native 数据集 parquet 和视频 chunk 文件大小。"""
        meta = getattr(dataset, "meta", None)
        update_chunk_settings = getattr(meta, "update_chunk_settings", None)
        if callable(update_chunk_settings):
            update_chunk_settings(
                data_files_size_in_mb=NATIVE_DATA_FILE_SIZE_MB,
                video_files_size_in_mb=NATIVE_VIDEO_FILE_SIZE_MB,
            )

    def _native_encoder_queue_maxsize(self) -> int:
        """从环境变量读取视频编码队列大小，非法时使用默认值。"""
        raw = os.environ.get("APPSTATION_LEROBOT_ENCODER_QUEUE_MAXSIZE", "180").strip()
        try:
            return max(1, int(raw))
        except ValueError:
            return 180

    def _native_encoder_threads(self) -> int | None:
        """从环境变量读取视频编码线程数，缺失或非法时交由默认值处理。"""
        raw = os.environ.get("APPSTATION_LEROBOT_ENCODER_THREADS", "").strip()
        if not raw:
            return None
        try:
            return max(1, int(raw))
        except ValueError:
            return None

    def _native_vcodec(self) -> str:
        """读取 native 视频编码器名称，未配置时使用 h264。"""
        return os.environ.get("APPSTATION_LEROBOT_VCODEC", "h264").strip() or "h264"

    def _resume_native_dataset_locked(self) -> Any:
        """在已有数据集目录上恢复 LeRobotDataset 并应用 chunk 设置。"""
        imports = self._native_imports()
        if imports is None:
            raise RuntimeError("lerobot[dataset] is not installed in backend runtime")
        if self._dataset_dir is None:
            raise RuntimeError("record dataset is not initialized")
        LeRobotDataset, _np = imports
        dataset = LeRobotDataset.resume(
            repo_id=f"local/{self._dataset_id}",
            root=self._dataset_dir,
            **self._native_writer_kwargs(),
        )
        self._configure_native_chunk_settings(dataset)
        return dataset

    def _is_native_dataset_info(self, info: dict[str, Any]) -> bool:
        """根据 info.json 的 format 判断是否为 native LeRobot 数据集。"""
        return str(info.get("format", "")) == "lerobot-v3-native"

    def _is_native_dataset(self, dataset_dir: Path, info: dict[str, Any]) -> bool:
        """结合 info.json 和 appstation_info 判断数据集是否为 native 格式。"""
        if self._is_native_dataset_info(info):
            return True
        app_info = self._read_json(dataset_dir / "meta" / "appstation_info.json")
        return str(app_info.get("format", "")) == "lerobot-v3-native"

    def _open_native_dataset_for_read(self, dataset_id: str, dataset_dir: Path, LeRobotDataset: Any) -> Any:
        """以兼容不同 LeRobot 版本的方式打开数据集用于预览读取。"""
        try:
            return LeRobotDataset(f"local/{dataset_id}", root=dataset_dir, return_uint8=True)
        except TypeError as exc:
            if "return_uint8" not in str(exc):
                raise
            return LeRobotDataset(f"local/{dataset_id}", root=dataset_dir)

    def _camera_recording_frame_with_time(self, config: dict[str, Any], camera: str) -> tuple[Any, float | None]:
        """获取相机 RGB 帧及采集线程时间，兼容多种 camera 接口。"""
        raw_snapshot_with_time = getattr(self.hardware.cameras, "snapshot_frame_with_timestamp", None)
        if callable(raw_snapshot_with_time):
            snapshot = raw_snapshot_with_time(config, camera)
            frame = getattr(snapshot, "frame", snapshot[0] if isinstance(snapshot, tuple) else snapshot)
            sampled_at = getattr(
                snapshot,
                "monotonic_s",
                snapshot[1] if isinstance(snapshot, tuple) and len(snapshot) > 1 else None,
            )
            return self._coerce_rgb_frame(frame, camera), self._coerce_float(sampled_at)
        raw_snapshot = getattr(self.hardware.cameras, "snapshot_frame", None)
        if callable(raw_snapshot):
            return self._coerce_rgb_frame(raw_snapshot(config, camera), camera), time.monotonic()
        jpeg = self.hardware.cameras.snapshot(config, camera)
        return self._decode_jpeg_to_rgb(jpeg, config, camera), time.monotonic()

    def _decode_jpeg_to_rgb(self, jpeg: bytes, config: dict[str, Any], camera: str = "global") -> Any:
        """将相机 JPEG bytes 解码、转 RGB 并缩放到保存尺寸。"""
        imports = self._native_imports()
        if imports is None:
            raise RuntimeError("native numpy import unavailable")
        _LeRobotDataset, np = imports
        cv2 = importlib.import_module("cv2")
        buffer = np.frombuffer(jpeg, dtype=np.uint8)
        frame = cv2.imdecode(buffer, cv2.IMREAD_COLOR)
        if frame is None:
            raise RuntimeError("JPEG decode failed")
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        width, height = CAMERA_CAPTURE_SIZES.get(camera, CAMERA_CAPTURE_SIZES["global"])
        if rgb.shape[:2] != (height, width):
            rgb = cv2.resize(rgb, (width, height), interpolation=cv2.INTER_AREA)
        return rgb

    def _coerce_rgb_frame(self, frame: Any, camera: str = "global") -> Any:
        """将任意 RGB 帧转换为 uint8 数组并缩放到 LeRobot feature 尺寸。"""
        imports = self._native_imports()
        if imports is None:
            return frame
        _LeRobotDataset, np = imports
        cv2 = importlib.import_module("cv2")
        rgb = np.asarray(frame, dtype=np.uint8)
        width, height = CAMERA_CAPTURE_SIZES.get(camera, CAMERA_CAPTURE_SIZES["global"])
        if rgb.shape[:2] != (height, width):
            rgb = cv2.resize(rgb, (width, height), interpolation=cv2.INTER_AREA)
        return rgb

    def _synthetic_camera_frame(self, feature_key: str) -> Any:
        """生成带相机和帧序号特征的占位 RGB 图像。"""
        imports = self._native_imports()
        if imports is None:
            return None
        _LeRobotDataset, np = imports
        camera = next((key for key, value in CAMERA_FEATURE_KEYS.items() if value == feature_key), "global")
        width, height = CAMERA_CAPTURE_SIZES.get(camera, CAMERA_CAPTURE_SIZES["global"])
        frame = np.zeros((height, width, 3), dtype=np.uint8)
        camera_index = (
            list(CAMERA_FEATURE_KEYS.values()).index(feature_key)
            if feature_key in CAMERA_FEATURE_KEYS.values()
            else 0
        )
        frame[:, :, 0] = (camera_index + 1) * 45
        frame[:, :, 1] = (self._episode_frames * 7) % 255
        frame[:, :, 2] = (camera_index + 1) * 70
        return frame

    def _camera_placeholder_value(self, feature_key: str) -> Any:
        """返回相机缺失时写入 native 数据集的占位图像。"""
        return self._synthetic_camera_frame(feature_key)

    def _last_camera_value(self, feature_key: str) -> Any:
        """返回最近成功采集的相机帧，缺失时生成占位图像。"""
        return self._last_native_camera_frames.get(feature_key) or self._synthetic_camera_frame(feature_key)

    def _np_float32(self, values: object) -> Any:
        """在 numpy 可用时把数值序列转换为 float32 数组。"""
        imports = self._native_imports()
        if imports is None:
            return values
        _LeRobotDataset, np = imports
        return np.asarray(values, dtype=np.float32)

    def _record_fps_from_config(self, config: dict[str, Any]) -> int:
        """从配置中读取录制 FPS，并限制在 1 到 60。"""
        try:
            raw = float(config.get("storage", {}).get("recordFps") or config.get("cameras", {}).get("fps", 30))
        except (TypeError, ValueError):
            raw = 30.0
        return int(min(max(round(raw), 1), 60))

    def _force_sample_hz_from_config(self, config: dict[str, Any]) -> float:
        """从配置中读取力传感器采样频率，并限制合法范围。"""
        if str(config.get("force", {}).get("source", "hkvl_serial")).lower() == "hkvl_serial":
            return 200.0
        try:
            raw = float(config.get("force", {}).get("sampleHz", 200))
        except (TypeError, ValueError):
            raw = 200.0
        return min(max(raw, 1.0), 10000.0)

    def _sync_recording_shape_from_native_info(self, dataset_dir: Path) -> None:
        """从 native info.json 同步录制帧率等形状参数。"""
        info = self._read_json(dataset_dir / "meta" / "info.json")
        try:
            self._record_fps_hz = int(info.get("fps", self._record_fps_hz))
        except (TypeError, ValueError):
            pass

    def _episode_for_api(
        self,
        dataset_dir: Path,
        dataset_id: str,
        episode: dict[str, Any],
        *,
        include_samples: bool = True,
    ) -> dict[str, Any]:
        """将内部 episode 元数据转换为前端 API 使用的摘要结构。"""
        samples = self._episode_samples(dataset_dir, dataset_id, episode) if include_samples else []
        quality = self._episode_quality(episode)
        features = self._feature_summary(dataset_dir)
        camera_resolutions = self._camera_resolution_summary(dataset_dir)
        return {
            "id": str(episode.get("id", "")),
            "name": str(episode.get("name") or episode.get("id") or "episode"),
            "task": str(episode.get("task") or ""),
            "status": str(episode.get("status") or "review"),
            "quality": quality,
            "frames": int(episode.get("frames", 0)),
            "fps": int(episode.get("fps", 30)),
            "durationS": float(episode.get("durationS", 0.0)),
            "createdAt": int(episode.get("createdAt", 0)),
            "warnings": list(episode.get("warnings", [])) if isinstance(episode.get("warnings"), list) else [],
            "samples": samples,
            "lateFrames": int(episode.get("lateFrames", 0)),
            "cameraDrops": episode.get("cameraDrops", {}),
            "dropCounts": episode.get("dropCounts", {}),
            "staleCounts": episode.get("staleCounts", {}),
            "cacheCounts": episode.get("cacheCounts", {}),
            "sourceMaxSkewMs": episode.get("sourceMaxSkewMs", {}),
            "maxForceLeft": float(episode.get("maxForceLeft", 0.0)),
            "maxForceRight": float(episode.get("maxForceRight", 0.0)),
            "motionOrigin": episode.get("motionOrigin", {}),
            "motionCalibration": episode.get("motionCalibration", {}),
            "features": features,
            "featureSummary": features,
            "cameraResolutions": camera_resolutions,
        }

    def _feature_summary(self, dataset_dir: Path) -> dict[str, Any]:
        """从数据集 info.json 提取前端需要展示的 feature 概览。"""
        info = self._read_json(dataset_dir / "meta" / "info.json")
        features = info.get("features", {})
        if not isinstance(features, dict):
            return {}
        wanted = [
            "observation.state",
            "action",
            "observation.pulses",
            "observation.force_left",
            "observation.force_right",
            *CAMERA_FEATURE_KEYS.values(),
        ]
        summary: dict[str, Any] = {}
        for key in wanted:
            value = features.get(key)
            if not isinstance(value, dict):
                continue
            summary[key] = {
                "shape": value.get("shape", []),
                "dtype": value.get("dtype", ""),
                "names": value.get("names", []),
            }
        return summary

    def _camera_resolution_summary(self, dataset_dir: Path) -> dict[str, dict[str, str]]:
        """从 AppStation 或 info 元数据汇总相机分辨率信息。"""
        info = self._read_json(dataset_dir / "meta" / "info.json")
        app_info = self._read_json(dataset_dir / "meta" / "appstation_info.json")
        hardware = app_info.get("hardware") if app_info else info.get("hardware", {})
        if isinstance(hardware, dict):
            existing = hardware.get("cameraResolutions")
            if isinstance(existing, dict):
                return existing
            return self._camera_resolution_summary_from_config({"cameras": hardware.get("cameras", {})})
        return self._camera_resolution_summary_from_config({})

    def _camera_resolution_summary_from_config(self, config: dict[str, Any]) -> dict[str, dict[str, str]]:
        """根据当前配置生成各相机物理、采集、预览和保存分辨率摘要。"""
        cameras = config.get("cameras", {}) if isinstance(config.get("cameras"), dict) else {}
        preview = str(cameras.get("previewResolution", "native"))
        result: dict[str, dict[str, str]] = {}
        for key in CAMERA_KEYS:
            width, height = CAMERA_CAPTURE_SIZES[key]
            configured = self._configured_camera_resolution(cameras, key)
            result[key] = {
                "physical": str(cameras.get(f"{key}PhysicalResolution", "native")),
                "capture": configured,
                "preview": preview,
                "saved": f"{width}x{height}",
            }
        return result

    def _configured_camera_resolution(self, cameras: dict[str, Any], camera: str) -> str:
        """按相机键名读取对应采集分辨率配置。"""
        key = f"{camera}Resolution"
        if camera == "wrist_left":
            key = "wristLeftResolution"
        elif camera == "wrist_right":
            key = "wristRightResolution"
        return str(cameras.get(key, cameras.get("previewResolution", "native")))

    def _episode_samples(
        self,
        dataset_dir: Path,
        dataset_id: str,
        episode: dict[str, Any],
        max_samples: int = 300,
    ) -> list[dict[str, Any]]:
        """为 episode 生成预览样本，native 数据集和 fallback jsonl 分别处理。"""
        native_episode = bool(episode.get("native", False))
        native_dataset = self._is_native_dataset(dataset_dir, self._read_json(dataset_dir / "meta" / "info.json"))
        if native_episode or native_dataset:
            return self._native_episode_samples(dataset_dir, dataset_id, episode, max_samples)
        data_path = str(episode.get("dataPath", ""))
        records = self._fallback_frame_records(dataset_dir, data_path)
        if not records:
            return []
        stride = max(1, len(records) // max_samples)
        samples: list[dict[str, Any]] = []
        for item in records[::stride]:
            samples.append(self._fallback_sample_for_api(dataset_id, episode, item, len(samples)))
        return samples

    def _fallback_frame_records(self, dataset_dir: Path, data_path: str) -> list[dict[str, Any]]:
        """从旧式 jsonl 数据文件读取帧记录，解析失败行会跳过。"""
        if not data_path:
            return []
        path = dataset_dir / data_path
        if not path.exists():
            return []
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
        records: list[dict[str, Any]] = []
        for line in lines:
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(item, dict):
                records.append(item)
        return records

    def _fallback_sample_for_api(
        self,
        dataset_id: str,
        episode: dict[str, Any],
        item: dict[str, Any],
        fallback_frame: int,
    ) -> dict[str, Any]:
        """将旧式帧记录转换为前端 episode sample 结构。"""
        state_raw = item.get("observation.state")
        if isinstance(state_raw, list) and len(state_raw) >= 14:
            state = self._lerobot14_to_ui_motion_state([float(value) for value in state_raw])
        elif isinstance(state_raw, list):
            state = lerobot_to_ui_state([float(value) for value in state_raw])
        else:
            state = [0.0] * 12
        pulses_raw = item.get("observation.pulses")
        pulses = [float(value) for value in pulses_raw] if isinstance(pulses_raw, list) else [0.0] * 12
        frame = int(item.get("frame_index", fallback_frame))
        images_raw = item.get("images")
        images: dict[str, str] = {}
        if isinstance(images_raw, dict):
            for key, feature_key in CAMERA_FEATURE_KEYS.items():
                raw_path = images_raw.get(feature_key)
                if isinstance(raw_path, str):
                    images[key] = self._fallback_image_url(dataset_id, str(episode.get("id", "")), key, frame, raw_path)
        for key, feature_key in CAMERA_FEATURE_KEYS.items():
            raw_path = item.get(feature_key)
            if isinstance(raw_path, str):
                images[key] = self._fallback_image_url(dataset_id, str(episode.get("id", "")), key, frame, raw_path)
        return {
            "frame": frame,
            "leftJoints": state[:6],
            "rightJoints": state[6:12],
            "leftPulses": pulses[:6],
            "rightPulses": pulses[6:12],
            "forceLeft": item.get("observation.force_left", [0.0] * 6),
            "forceRight": item.get("observation.force_right", [0.0] * 6),
            "images": images,
        }

    def _fallback_image_url(
        self,
        dataset_id: str,
        episode_id: str,
        camera: str,
        frame: int,
        relative_path: str,
    ) -> str:
        """根据旧式图像文件类型生成 API 访问 URL。"""
        if relative_path.lower().endswith(".mp4"):
            return (
                f"/api/datasets/{dataset_id}/frame_image"
                f"?episode_id={episode_id}&camera={camera}&frame={frame}"
            )
        return f"/api/datasets/{dataset_id}/file?path={relative_path}"

    def _native_episode_samples(
        self,
        dataset_dir: Path,
        dataset_id: str,
        episode: dict[str, Any],
        max_samples: int,
    ) -> list[dict[str, Any]]:
        """从 native LeRobot 数据集中抽样读取 episode 预览帧。"""
        imports = self._native_imports()
        if imports is None:
            return []
        LeRobotDataset, _np = imports
        try:
            dataset = self._open_native_dataset_for_read(dataset_id, dataset_dir, LeRobotDataset)
        except Exception:
            return self._native_placeholder_episode_samples(dataset_id, episode, max_samples)
        start = int(episode.get("datasetFromIndex") or 0)
        stop = int(episode.get("datasetToIndex") or min(len(dataset), start + int(episode.get("frames", 0))))
        stop = min(stop, len(dataset))
        if stop <= start:
            return self._native_placeholder_episode_samples(dataset_id, episode, max_samples)
        stride = max(1, (stop - start) // max_samples)
        samples: list[dict[str, Any]] = []
        episode_id = str(episode.get("id", ""))
        for absolute_index in range(start, stop, stride):
            try:
                item = dataset[absolute_index]
            except Exception:
                continue
            state = self._tensor_to_float_list(item.get("observation.state"), expected=14)
            pulses = self._tensor_to_float_list(item.get("observation.pulses"), expected=12)
            force_left = self._tensor_to_float_list(item.get("observation.force_left"), expected=6)
            force_right = self._tensor_to_float_list(item.get("observation.force_right"), expected=6)
            frame = int(item.get("frame_index", absolute_index - start))
            images = {
                key: (
                    f"/api/datasets/{dataset_id}/frame_image"
                    f"?episode_id={episode_id}&camera={key}&frame={frame}"
                )
                for key in CAMERA_KEYS
            }
            samples.append(
                {
                    "frame": frame,
                    "leftJoints": self._lerobot14_to_ui_motion_state(state)[:6],
                    "rightJoints": self._lerobot14_to_ui_motion_state(state)[6:12],
                    "leftPulses": pulses[:6],
                    "rightPulses": pulses[6:12],
                    "forceLeft": force_left,
                    "forceRight": force_right,
                    "images": images,
                }
            )
        return samples or self._native_placeholder_episode_samples(dataset_id, episode, max_samples)

    def _native_placeholder_episode_samples(
        self,
        dataset_id: str,
        episode: dict[str, Any],
        max_samples: int,
    ) -> list[dict[str, Any]]:
        """Return lightweight preview rows when the native dataset is not readable yet."""
        frames = max(0, int(episode.get("frames", 0) or 0))
        if frames <= 0:
            return []
        stride = max(1, frames // max_samples)
        episode_id = str(episode.get("id", ""))
        samples: list[dict[str, Any]] = []
        for frame in range(0, frames, stride):
            images = {
                key: (
                    f"/api/datasets/{dataset_id}/frame_image"
                    f"?episode_id={episode_id}&camera={key}&frame={frame}"
                )
                for key in CAMERA_KEYS
            }
            samples.append(
                {
                    "frame": frame,
                    "leftJoints": [0.0] * 6,
                    "rightJoints": [0.0] * 6,
                    "leftPulses": [0.0] * 6,
                    "rightPulses": [0.0] * 6,
                    "forceLeft": [0.0] * 6,
                    "forceRight": [0.0] * 6,
                    "images": images,
                }
            )
        return samples

    def _tensor_to_float_list(self, value: Any, *, expected: int) -> list[float]:
        """将 tensor、numpy 或 list 值转换为固定长度 float 列表。"""
        if value is None:
            return [0.0] * expected
        if hasattr(value, "detach"):
            value = value.detach().cpu().tolist()
        elif hasattr(value, "tolist"):
            value = value.tolist()
        if not isinstance(value, list):
            return [0.0] * expected
        result = [float(item) for item in value[:expected]]
        return result + [0.0] * max(0, expected - len(result))

    def _native_episodes_from_meta(self, dataset_dir: Path, info: dict[str, Any]) -> list[dict[str, Any]]:
        """从 LeRobot episode parquet 元数据重建 episode 列表。"""
        if not self._is_native_dataset(dataset_dir, info):
            return []
        try:
            pq = importlib.import_module("pyarrow.parquet")
        except Exception:
            return []
        episodes: list[dict[str, Any]] = []
        for path in sorted((dataset_dir / "meta" / "episodes").glob("chunk-*/file-*.parquet")):
            try:
                data = pq.read_table(path).to_pydict()
            except Exception:
                continue
            count = len(data.get("episode_index", []))
            for row in range(count):
                episode_index = int(data.get("episode_index", [row])[row])
                tasks = data.get("tasks", [[""]])[row]
                task = str(tasks[0]) if isinstance(tasks, list) and tasks else ""
                start = int(data.get("dataset_from_index", [0])[row])
                stop = int(data.get("dataset_to_index", [start])[row])
                frames = int(data.get("length", [max(0, stop - start)])[row])
                episodes.append(
                    {
                        "id": f"episode_{episode_index:06d}",
                        "name": f"episode_{episode_index:06d}",
                        "task": task,
                        "status": "review",
                        "deleted": False,
                        "episodeIndex": episode_index,
                        "frames": frames,
                        "fps": int(info.get("fps", 30)),
                        "durationS": round(frames / max(1, int(info.get("fps", 30))), 3),
                        "createdAt": int(path.stat().st_mtime * 1000),
                        "datasetFromIndex": start,
                        "datasetToIndex": stop,
                        "native": True,
                        "lateFrames": 0,
                        "cameraDrops": {key: 0 for key in CAMERA_KEYS},
                        "dropCounts": {key: 0 for key in (*CAMERA_KEYS, *SOURCE_KEYS)},
                        "staleCounts": {key: 0 for key in SOURCE_KEYS},
                        "cacheCounts": {key: 0 for key in SOURCE_KEYS},
                        "maxSkewMs": 0.0,
                        "avgSkewMs": 0.0,
                        "jitterMs": 0.0,
                        "sourceMaxSkewMs": {key: 0.0 for key in SOURCE_KEYS},
                        "sourceAvgSkewMs": {key: 0.0 for key in SOURCE_KEYS},
                        "sourceJitterMs": {key: 0.0 for key in SOURCE_KEYS},
                        "maxForceLeft": 0.0,
                        "maxForceRight": 0.0,
                        "warnings": [],
                    }
                )
        return episodes

    def _visible_episodes_for_dataset(self, dataset_dir: Path, info: dict[str, Any]) -> list[dict[str, Any]]:
        """读取未删除 episode，必要时从 native 元数据回填。"""
        episodes = self._read_episodes(dataset_dir)
        if not episodes and self._is_native_dataset(dataset_dir, info):
            episodes = self._native_episodes_from_meta(dataset_dir, info)
        return [episode for episode in episodes if not bool(episode.get("deleted", False))]

    def _positive_ratio(self, value: Any, default: float) -> float:
        """将配置值解析为非负 float，失败时使用默认值。"""
        try:
            parsed = float(value)
        except (TypeError, ValueError):
            parsed = default
        return max(parsed, 0.0)

    def _compose_observation_state(self, motion_positions: list[float], gripper_positions: list[Any]) -> list[float]:
        # 将运动状态和夹爪位置组合成 LeRobot v3 的 state。
        """把 12 维运动位姿和左右夹爪值拼成 14 维 LeRobot state。"""
        motion = (list(motion_positions) + [0.0] * 12)[:12]
        gripper = [self._float_or_zero(value) for value in (list(gripper_positions) + [0.0, 0.0])[:2]]
        return [
            motion[0],
            motion[1],
            motion[2],
            motion[3] * 1000.0,
            motion[4] * 1000.0,
            motion[5] * 1000.0,
            gripper[0],
            motion[6],
            motion[7],
            motion[8],
            motion[9] * 1000.0,
            motion[10] * 1000.0,
            motion[11] * 1000.0,
            gripper[1],
        ]

    def _lerobot14_to_ui_motion_state(self, state: list[float]) -> list[float]:
        # 将运动状态和夹爪位置组合成 LeRobot v3 的 state。
        """将 14 维 LeRobot state 转回前端使用的 12 维运动位姿。"""
        values = (list(state) + [0.0] * 14)[:14]
        return [
            values[0],
            values[1],
            values[2],
            values[3] / 1000.0,
            values[4] / 1000.0,
            values[5] / 1000.0,
            values[7],
            values[8],
            values[9],
            values[10] / 1000.0,
            values[11] / 1000.0,
            values[12] / 1000.0,
        ]

    def _float_or_zero(self, value: Any) -> float:
        """将值转为非负有限 float，非法或负数时返回 0。"""
        try:
            result = float(value)
        except (TypeError, ValueError):
            return 0.0
        if not math.isfinite(result) or result < 0:
            return 0.0
        return result

    def _encode_rgb_tensor_to_jpeg(self, image: Any, np: Any) -> bytes:
        """将 LeRobot 读取出的 RGB 张量或数组编码为 JPEG bytes。"""
        if image is None:
            raise FileNotFoundError("image")
        if hasattr(image, "detach"):
            image = image.detach().cpu().numpy()
        elif hasattr(image, "numpy"):
            image = image.numpy()
        array = np.asarray(image)
        if array.ndim != 3:
            raise FileNotFoundError("image")
        if array.shape[0] == 3 and array.shape[2] != 3:
            array = np.transpose(array, (1, 2, 0))
        if array.dtype != np.uint8:
            max_value = float(array.max()) if array.size else 0.0
            if max_value <= 1.0:
                array = array * 255.0
            array = np.clip(array, 0, 255).astype(np.uint8)
        cv2 = importlib.import_module("cv2")
        bgr = cv2.cvtColor(array, cv2.COLOR_RGB2BGR)
        ok, buffer = cv2.imencode(".jpg", bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 82])
        if not ok:
            raise FileNotFoundError("image")
        return bytes(buffer)

    def _decode_video_frame_to_jpeg(self, path: Path, frame_index: int) -> bytes:
        # fallback MP4 复核时按 frame_index 解码单帧，保持前端仍然拿到 JPEG。
        """从视频文件按帧号解码单帧并编码为 JPEG bytes。"""
        cv2 = importlib.import_module("cv2")
        capture = cv2.VideoCapture(str(path))
        try:
            if not capture.isOpened():
                raise FileNotFoundError(str(path))
            capture.set(cv2.CAP_PROP_POS_FRAMES, max(0, int(frame_index)))
            ok, frame = capture.read()
            if not ok or frame is None:
                raise FileNotFoundError(f"{path}:{frame_index}")
            ok, buffer = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 82])
            if not ok:
                raise FileNotFoundError("image")
            return bytes(buffer)
        finally:
            capture.release()

    def _episode_quality(self, episode: dict[str, Any]) -> int:
        """根据迟到帧和相机丢帧数估算 episode 质量分。"""
        late = int(episode.get("lateFrames", 0))
        drops_raw = episode.get("cameraDrops", {})
        drops = sum(int(value) for value in drops_raw.values()) if isinstance(drops_raw, dict) else 0
        return max(40, min(99, 96 - late * 2 - drops * 3))

    def _quality_warnings(self) -> list[str]:
        """汇总当前 episode 的迟到、偏差、陈旧、缓存和相机丢帧告警。"""
        warnings: list[str] = []
        if self._episode_late_frames:
            warnings.append(f"late frames: {self._episode_late_frames}")
        skew = self._skew_stats()
        if skew["maxSkewMs"] > 20.0:
            warnings.append(f"max skew: {skew['maxSkewMs']}ms")
        warnings.extend(self._source_latency_warnings())
        warnings.extend(
            warning
            for warning in dict.fromkeys(self._source_warnings)
            if not self._is_source_latency_detail_warning(warning)
        )
        for source, count in self._stale_counts.items():
            if count:
                warnings.append(f"{source} stale: {count}")
        for source, count in self._cache_counts.items():
            if count:
                warnings.append(f"{source} cache used: {count}")
        for key, count in self._camera_drops.items():
            if count:
                warnings.append(f"{key} camera drops: {count}")
        for key, fps in getattr(self, "_camera_min_fps", {}).items():
            if fps < 25.0:
                warnings.append(f"{key} camera low fps: {round(float(fps), 1)}Hz")
        for key in sorted(getattr(self, "_camera_worker_fallbacks", set())):
            warnings.append(f"{key} camera worker fallback")
        return warnings

    def _source_latency_warnings(self) -> list[str]:
        """将逐帧 source skew 压缩成每个异常源一条延迟统计。"""
        warnings: list[str] = []
        late_source_frames = getattr(self, "_late_source_frames", {})
        source_skews_ms = getattr(self, "_source_skews_ms", {})
        if not isinstance(late_source_frames, dict) or not isinstance(source_skews_ms, dict):
            return warnings
        for source, warning_count in late_source_frames.items():
            try:
                count = int(warning_count)
            except (TypeError, ValueError):
                continue
            if count <= 0:
                continue
            raw_values = source_skews_ms.get(source, [])
            values = [abs(float(value)) for value in raw_values] if isinstance(raw_values, list) else []
            if values:
                avg_ms = round(sum(values) / len(values), 3)
                max_ms = round(max(values), 3)
                warnings.append(
                    f"{source} latency summary: samples={len(values)} warnings={count} avg={avg_ms}ms max={max_ms}ms"
                )
            else:
                warnings.append(f"{source} latency summary: samples=0 warnings={count}")
        return warnings

    def _is_source_latency_detail_warning(self, warning: str) -> bool:
        """识别旧的逐帧 source skew 明细，避免质量报告继续刷屏。"""
        return re.fullmatch(r"[A-Za-z0-9_]+ skew [-+]?\d+(?:\.\d+)?ms", warning.strip()) is not None

    def _skew_stats(self) -> dict[str, float]:
        # 记录每个硬件源相对录制 tick 的时序，用于质量统计而不写入训练帧。
        """计算当前 episode 训练帧调度偏差的最大值、均值和抖动。"""
        values = [abs(value) for value in self._tick_skews_ms]
        if not values:
            return {"maxSkewMs": 0.0, "avgSkewMs": 0.0, "jitterMs": 0.0}
        deltas = [
            abs(values[index] - values[index - 1])
            for index in range(1, len(values))
        ]
        jitter = sum(deltas) / len(deltas) if deltas else 0.0
        return {
            "maxSkewMs": round(max(values), 3),
            "avgSkewMs": round(sum(values) / len(values), 3),
            "jitterMs": round(jitter, 3),
        }

    def _source_skew_stats(self) -> dict[str, dict[str, float]]:
        """计算各采样源对目标时间偏差的最大值、均值和抖动。"""
        max_skew: dict[str, float] = {}
        avg_skew: dict[str, float] = {}
        jitter: dict[str, float] = {}
        for source, raw_values in self._source_skews_ms.items():
            values = [abs(value) for value in raw_values]
            if not values:
                max_skew[source] = 0.0
                avg_skew[source] = 0.0
                jitter[source] = 0.0
                continue
            deltas = [abs(values[index] - values[index - 1]) for index in range(1, len(values))]
            max_skew[source] = round(max(values), 3)
            avg_skew[source] = round(sum(values) / len(values), 3)
            jitter[source] = round(sum(deltas) / len(deltas), 3) if deltas else 0.0
        return {"maxSkewMs": max_skew, "avgSkewMs": avg_skew, "jitterMs": jitter}

    def _latest_action_vector(
        self,
        observation_state: list[float] | None = None,
        config: dict[str, Any] | None = None,
        target_monotonic_s: float | None = None,
    ) -> list[float]:
        # action 记录绝对目标：当前 observation.state 加主手增量，夹爪目标取实时目标或配置值。
        """根据 observation、teleop 增量和夹爪目标生成 14 维 action。"""
        base = (list(observation_state) + [0.0] * 14)[:14] if observation_state is not None else [0.0] * 14
        config = config or {}
        vector = self._latest_action_delta_vector(target_monotonic_s)
        action = [base[index] + vector[index] for index in range(14)]
        native_gripper_targets = self._latest_native_gripper_targets(config)
        if native_gripper_targets is not None:
            action[6], action[13] = native_gripper_targets
            return action
        if not self._using_real_hal_native_teleop(config):
            gripper = config.get("gripper", {}) if isinstance(config.get("gripper"), dict) else {}
            if gripper:
                action[6] = self._float_or_zero(gripper.get("targetLeftMm", base[6]))
                action[13] = self._float_or_zero(gripper.get("targetRightMm", base[13]))
        return action

    def _latest_native_gripper_targets(self, config: dict[str, Any]) -> tuple[float, float] | None:
        """从 native teleop 状态中提取左右夹爪目标值。"""
        status = self.teleop.status()
        native_status = status.get("nativeStatus") if isinstance(status, dict) else None
        if not isinstance(native_status, dict):
            return None
        raw_targets = native_status.get("gripperTargets")
        if isinstance(raw_targets, list) and len(raw_targets) >= 2:
            left = self._coerce_float(raw_targets[0])
            right = self._coerce_float(raw_targets[1])
        elif isinstance(raw_targets, dict):
            left = self._coerce_float(raw_targets.get("leftMm", raw_targets.get("left")))
            right = self._coerce_float(raw_targets.get("rightMm", raw_targets.get("right")))
        else:
            return None
        if left is None or right is None:
            return None
        return left, right

    def _latest_action_delta_vector(self, target_monotonic_s: float | None = None) -> list[float]:
        """汇总目标时间附近 teleop 动作形成 14 维动作增量。"""
        vector = [0.0] * 14
        for action in self._teleop_actions_for_target(target_monotonic_s):
            action_delta = self._action_delta_vector(action)
            vector = [vector[index] + action_delta[index] for index in range(14)]
        return vector

    def _action_delta_vector(self, action: dict[str, Any]) -> list[float]:
        """将单个 teleop 动作转换为 14 维 LeRobot action 增量。"""
        vector = [0.0] * 14
        delta_vector = action.get("deltaVector")
        if isinstance(delta_vector, list):
            return self._motion_delta_to_action_delta(delta_vector)
        side = action.get("side")
        axis = action.get("axis")
        if side not in {"left", "right"} or axis not in {"X", "Y", "Z", "Roll", "Pitch", "Yaw"}:
            return vector
        axis_index = ["X", "Y", "Z", "Roll", "Pitch", "Yaw"].index(str(axis))
        state_index = (0 if side == "left" else 7) + axis_index
        value = float(action.get("delta", 0.0))
        vector[state_index] = value * 1000.0 if axis_index >= 3 else value
        return vector

    def _teleop_actions_for_target(self, target_monotonic_s: float | None) -> list[dict[str, Any]]:
        """选择目标时间之前仍新鲜的 teleop 动作列表。"""
        status = self.teleop.status()
        if target_monotonic_s is None:
            last_action = status.get("lastAction")
            if not isinstance(last_action, dict):
                return []
            ts = int(last_action.get("ts", 0))
            return [last_action] if now_ms() - ts <= int(ACTION_STALE_S * 1000) else []
        latest_by_side: dict[str, tuple[float, dict[str, Any]]] = {}
        latest_global: tuple[float, dict[str, Any]] | None = None
        history = status.get("actionHistory")
        if isinstance(history, list):
            for item in history:
                if not isinstance(item, dict):
                    continue
                monotonic_s = self._action_monotonic_s(item)
                if monotonic_s is None or monotonic_s > target_monotonic_s:
                    continue
                if target_monotonic_s - monotonic_s > ACTION_STALE_S:
                    continue
                side = item.get("side")
                if side in {"left", "right"}:
                    current = latest_by_side.get(side)
                    if current is None or monotonic_s > current[0]:
                        latest_by_side[str(side)] = (monotonic_s, item)
                elif latest_global is None or monotonic_s > latest_global[0]:
                    latest_global = (monotonic_s, item)
        if latest_by_side:
            return [entry[1] for entry in latest_by_side.values()]
        if latest_global is not None:
            return [latest_global[1]]
        last_action = status.get("lastAction")
        if not isinstance(last_action, dict):
            return []
        monotonic_s = self._action_monotonic_s(last_action)
        if monotonic_s is None or monotonic_s > target_monotonic_s:
            return []
        if target_monotonic_s - monotonic_s > ACTION_STALE_S:
            return []
        return [last_action]

    def _teleop_action_for_target(self, target_monotonic_s: float | None) -> dict[str, Any] | None:
        """返回不晚于目标时间的最新 teleop 动作。"""
        status = self.teleop.status()
        if target_monotonic_s is None:
            last_action = status.get("lastAction")
            return last_action if isinstance(last_action, dict) else None
        best_action: dict[str, Any] | None = None
        best_monotonic_s = -math.inf
        history = status.get("actionHistory")
        if isinstance(history, list):
            for item in history:
                if not isinstance(item, dict):
                    continue
                monotonic_s = self._action_monotonic_s(item)
                if monotonic_s is None or monotonic_s > target_monotonic_s or monotonic_s < best_monotonic_s:
                    continue
                best_action = item
                best_monotonic_s = monotonic_s
        if best_action is not None:
            return best_action
        last_action = status.get("lastAction")
        if not isinstance(last_action, dict):
            return None
        monotonic_s = self._action_monotonic_s(last_action)
        if monotonic_s is None or monotonic_s > target_monotonic_s:
            return None
        return last_action

    def _action_monotonic_s(self, action: dict[str, Any]) -> float | None:
        """从 teleop 动作中解析 HAL steady_clock 时间戳。"""
        for raw, scale in (
            (action.get("monotonicMs"), 0.001),
            (action.get("monotonic_s"), 1.0),
        ):
            parsed = self._coerce_float(raw)
            if parsed is not None and parsed >= 0:
                return parsed * scale
        return None

    def _motion_delta_to_action_delta(self, delta_vector: list[Any]) -> list[float]:
        # teleop delta 仍是 12 维位姿增量，这里插入左右夹爪槽位并把旋转从度转成 mdeg。
        """将 12 维运动增量插入夹爪槽位并转换旋转单位。"""
        motion = [0.0] * 12
        for index, value in enumerate(delta_vector[:12]):
            try:
                motion[index] = float(value)
            except (TypeError, ValueError):
                motion[index] = 0.0
        return [
            motion[0],
            motion[1],
            motion[2],
            motion[3] * 1000.0,
            motion[4] * 1000.0,
            motion[5] * 1000.0,
            0.0,
            motion[6],
            motion[7],
            motion[8],
            motion[9] * 1000.0,
            motion[10] * 1000.0,
            motion[11] * 1000.0,
            0.0,
        ]

    def _dataset_root(self, config: dict[str, Any]) -> Path:
        """从配置读取数据集根目录并展开用户目录。"""
        raw = str(config.get("storage", {}).get("datasetRoot", "~/.appstation/datasets"))
        return Path(raw).expanduser()

    def _dataset_path(self, dataset_id: str) -> Path:
        """根据数据集 id 生成安全的数据集目录路径。"""
        root = self._dataset_root(self.settings.get_config())
        return root / self._safe_id(dataset_id)

    def _require_dataset_dir(self) -> Path:
        """返回当前会话数据集目录，未初始化时抛出异常。"""
        if self._dataset_dir is None:
            raise RuntimeError("record dataset is not initialized")
        return self._dataset_dir

    def _next_episode_index(self, dataset_dir: Path) -> int:
        """根据已有 episode 元数据计算下一条 episode 序号。"""
        episodes = self._read_episodes(dataset_dir)
        if not episodes:
            episodes = self._native_episodes_from_meta(dataset_dir, self._read_json(dataset_dir / "meta" / "info.json"))
        indices = [int(item.get("episodeIndex", -1)) for item in episodes]
        return max(indices, default=-1) + 1

    def _read_episodes(self, dataset_dir: Path) -> list[dict[str, Any]]:
        """读取 episodes.jsonl 中的 episode 元数据列表。"""
        path = dataset_dir / "meta" / "episodes.jsonl"
        if not path.exists():
            return []
        episodes: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if isinstance(item, dict):
                episodes.append(item)
        return episodes

    def _write_episodes(self, dataset_dir: Path, episodes: list[dict[str, Any]]) -> None:
        """将 episode 元数据列表写回 episodes.jsonl。"""
        path = dataset_dir / "meta" / "episodes.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        content = "".join(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n" for item in episodes)
        path.write_text(content, encoding="utf-8")

    def _episode_dataset_stub(self, dataset_dir: Path) -> dict[str, Any]:
        """从元数据生成前端需要的最小数据集标识和名称。"""
        info = self._read_json(dataset_dir / "meta" / "info.json")
        app_info = self._read_json(dataset_dir / "meta" / "appstation_info.json")
        name = app_info.get("name") or info.get("name") or dataset_dir.name
        return {"id": dataset_dir.name, "name": str(name)}

    def _read_json(self, path: Path) -> dict[str, Any]:
        """安全读取 JSON 对象文件，缺失或格式错误时返回空字典。"""
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return {}
        return data if isinstance(data, dict) else {}

    def _write_json(self, path: Path, data: dict[str, Any]) -> None:
        """确保父目录存在后以 UTF-8 写入格式化 JSON。"""
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def _safe_id(self, value: str) -> str:
        """将名称清洗为可用于目录名的数据集 id。"""
        normalized = SAFE_ID.sub("_", value.strip()).strip("._-")
        return normalized[:80] or "dataset"

    def _real_hardware_mode(self, config: dict[str, Any]) -> bool:
        """根据环境变量或配置判断当前是否使用真实硬件。"""
        mode = os.environ.get("APPSTATION_HAL_MODE") or config.get("hal", {}).get("mode", "real")
        return str(mode).lower() == "real"

    def _using_real_hal_native_teleop(self, config: dict[str, Any]) -> bool:
        """判断当前录制是否由 HAL-native 直接提供实机 teleop 数据。"""
        teleop = config.get("teleop", {}) if isinstance(config.get("teleop"), dict) else {}
        return self._real_hardware_mode(config) and str(teleop.get("engine", "")).lower() == "hal_native"

    def _force_norm(self, values: object) -> float:
        """计算前三轴力值的最大绝对值作为力幅度指标。"""
        if not isinstance(values, list) or len(values) < 3:
            return 0.0
        return max(abs(float(values[0])), abs(float(values[1])), abs(float(values[2])))
