"""HAL client adapters."""
