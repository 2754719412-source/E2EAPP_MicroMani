"""Core backend utilities."""
