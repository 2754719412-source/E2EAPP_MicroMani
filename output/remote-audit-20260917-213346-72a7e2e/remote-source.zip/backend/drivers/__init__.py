"""Real hardware driver adapters."""
